# ========== OTA Utility Functions (from ota_modified) ==========
import hmac, hashlib, time
import secrets

def generate_token():
    return secrets.token_hex(32)

def verify_signature(device_id, version, ts, signature, token):
    ts_str = str(int(ts))
    msg = f"{device_id}|{version}|{ts_str}".encode()
    expected = hmac.new(
        token.encode(),
        msg,
        hashlib.sha256
    ).hexdigest()

    return hmac.compare_digest(expected, signature)
"""
Utility functions for aggregating sensor data and calculating usage metrics
"""
from django.db.models import Sum, Avg, Count, Max, Min
from datetime import datetime, timedelta, date
from .models import SensorData, WaterUsage, Customer


def get_customer_by_identifier(identifier):
    """Resolve customer by numeric id or email string."""
    if not identifier:
        return None
    if isinstance(identifier, Customer):
        return identifier
    lookup = str(identifier).strip()
    if not lookup:
        return None
    customer = None
    try:
        if lookup.isdigit():
            customer = Customer.objects.filter(id=int(lookup)).first()
    except (ValueError, TypeError):
        customer = None
    if customer:
        return customer
    try:
        return Customer.objects.get(email__iexact=lookup)
    except Customer.DoesNotExist:
        return None

# OTA utility functions (from otamodified, renamed)
import hmac, hashlib, secrets

def generate_ota_token():
    return secrets.token_hex(32)


def get_device_token(device_id):
    """Get device token for a given device_id"""
    try:
        customer = Customer.objects.get(device_chip_id=device_id, is_active=True, block_unblock=True)
        return customer.device_token
    except Customer.DoesNotExist:
        return None


def verify_sensor_signature(device_id, ts, signature, token, payload):
    """
    Verify signature for sensor data using the ORIGINAL payload string from request,
    not the re-serialized version after deserialization.
    """
    # This payload is already deserialized by DRF serializer
    # We need to use the raw JSON string from the request instead
    payload_json = json.dumps(
        payload,
        separators=(",", ":"),
        sort_keys=False,  # Don't sort keys
        ensure_ascii=False
    )
    msg = f"{device_id}{ts}{payload_json}"
    expected = hmac.new(
        token.encode(),
        msg.encode(),
        hashlib.sha256
    ).hexdigest()
    print("SERVER_MSG =", msg)
    print("SERVER_SIG =", expected)
    print("CLIENT_SIG =", signature)
    return hmac.compare_digest(expected, signature)


def verify_ota_signature(device_id, version, ts, signature, token):
    ts_str = str(int(ts))
    msg = f"{device_id}|{version}|{ts_str}".encode()
    expected = hmac.new(
        token.encode(),
        msg,
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected, signature)


def aggregate_sensor_data_by_day(customer, target_date=None):
    """
    Aggregate per-second sensor data for a specific day into daily summary.
    
    Args:
        customer: Customer object
        target_date: Date object (defaults to today)
    
    Returns:
        Dictionary with aggregated data
    """
    if target_date is None:
        target_date = date.today()
    
    # Get all sensor readings for the specified date
    daily_readings = SensorData.objects.filter(
        customer=customer,
        date=target_date
    )
    
    if not daily_readings.exists():
        return None
    
    # Aggregate the data
    aggregated = daily_readings.aggregate(
        total_readings=Count('id'),
        total_flow=Sum('total_flow'),
        avg_flow_rate=Avg('flow_rate'),
        max_flow_rate=Max('flow_rate'),
        min_flow_rate=Min('flow_rate'),
        avg_temperature=Avg('temperature'),
        avg_ph=Avg('ph'),
        avg_tds=Avg('tds'),
        first_reading=Min('timestamp'),
        last_reading=Max('timestamp'),
    )
    
    return aggregated


def calculate_daily_usage(customer, target_date=None):
    """
    Calculate and store daily water usage from sensor data.
    
    Args:
        customer: Customer object
        target_date: Date object (defaults to today)
    """
    if target_date is None:
        target_date = date.today()
    
    # Get aggregated sensor data for the day
    daily_data = aggregate_sensor_data_by_day(customer, target_date)
    
    if not daily_data:
        return None
    
    # Calculate usage metrics
    current_day_usage = daily_data['total_flow'] or 0
    
    # Calculate last 24 hours usage
    last_24hr = SensorData.objects.filter(
        customer=customer,
        timestamp__gte=datetime.now() - timedelta(hours=24)
    ).aggregate(total=Sum('total_flow'))['total'] or 0
    
    # Calculate monthly usage (current month)
    first_day_of_month = target_date.replace(day=1)
    monthly = SensorData.objects.filter(
        customer=customer,
        date__gte=first_day_of_month,
        date__lte=target_date
    ).aggregate(total=Sum('total_flow'))['total'] or 0
    
    # Calculate per day average using month-to-date data
    days_in_month = (target_date - first_day_of_month).days + 1
    per_day_avg = monthly / days_in_month if days_in_month > 0 else monthly
    
    # Create or update WaterUsage record
    usage, created = WaterUsage.objects.update_or_create(
        customer=customer,
        usage_date=target_date,
        defaults={
            'current_day_usage': current_day_usage,
            'last_24hr_usage': last_24hr,
            'monthly_usage': monthly,
            'per_day_average': per_day_avg,
        }
    )
    
    return usage


def get_sensor_data_for_date_range(customer, start_date, end_date):
    """
    Get sensor data grouped by date for a date range.
    
    Args:
        customer: Customer object
        start_date: Starting date
        end_date: Ending date
    
    Returns:
        QuerySet of sensor readings
    """
    return SensorData.objects.filter(
        customer=customer,
        esp_timestamp__date__gte=start_date,
        esp_timestamp__date__lte=end_date
    ).order_by('esp_timestamp')


def get_hourly_usage_for_day(customer, target_date=None):
    """
    Get hourly breakdown of water usage for a specific day.
    
    Args:
        customer: Customer object
        target_date: Date object (defaults to today)
    
    Returns:
        List of dictionaries with hourly data
    """
    if target_date is None:
        target_date = date.today()
    
    from django.db.models.functions import TruncHour
    
    hourly_data = SensorData.objects.filter(
        customer=customer,
        date=target_date
    ).annotate(
        hour=TruncHour('timestamp')
    ).values('hour').annotate(
        total_flow=Sum('total_flow'),
        avg_flow_rate=Avg('flow_rate'),
        reading_count=Count('id')
    ).order_by('hour')
    
    return list(hourly_data)


def simulate_sensor_reading(customer, flow_rate=0.5, temperature=25.0, ph=7.0, tds=150.0):
    """
    Create a simulated sensor reading (useful for testing).
    
    Args:
        customer: Customer object
        flow_rate: Flow rate in liters per second
        temperature: Water temperature in Celsius
        ph: pH level
        tds: Total Dissolved Solids in ppm
    
    Returns:
        Created SensorData object
    """
    # Get the last reading to calculate cumulative flow
    last_reading = SensorData.objects.filter(
        customer=customer,
        esp_timestamp__date=date.today()
    ).order_by('-esp_timestamp').first()
    import random
    # Always increment by a random value if flow_rate is not provided
    increment = flow_rate if flow_rate else random.uniform(0.5, 2.0)
    total_volume = (last_reading.total_volume if last_reading else 0) + increment
    
    # Determine water quality based on TDS
    if tds < 300:
        water_quality = "Excellent"
    elif tds < 600:
        water_quality = "Good"
    elif tds < 900:
        water_quality = "Fair"
    else:
        water_quality = "Poor"
    
    reading = SensorData.objects.create(
        customer=customer,
        esp_timestamp=timezone.now(),
        total_volume=total_volume,
        current_volume=flow_rate,
        ph=ph,
        tds=tds,
        water_quality=water_quality,
        device_health='Healthy'
    )
    
    return reading


def deduct_from_recharge(customer, usage_litres):
    """
    Deduct water usage from customer's recharges using FIFO (First In First Out).
    This ensures the oldest recharge is consumed first before moving to newer ones.
    Allows continuous usage even when recharges run out (overuse tracking).
    
    Args:
        customer: Customer object
        usage_litres: Amount of water to deduct in litres
    
    Returns:
        Boolean indicating if deduction was successful (always True for continuous usage)
    """
    if usage_litres <= 0:
        return True
    
    from .models import Recharge
    
    # Get active recharges ordered by recharge_date (oldest first) - FIFO
    active_recharges = Recharge.objects.filter(
        customer=customer,
        status='active',
        litres_remaining__gt=0
    ).order_by('recharge_date')  # Oldest first!
    
    if not active_recharges.exists():
        # No active recharges - allow continuous usage (overuse)
        # Water usage is still recorded but not deducted from any recharge
        return True
    
    remaining_usage = usage_litres
    
    # Deduct from oldest recharges first
    for recharge in active_recharges:
        if remaining_usage <= 0:
            break
        
        # Calculate how much we can deduct from this recharge
        deductible = min(remaining_usage, recharge.litres_remaining)
        
        # Update recharge
        recharge.litres_used += deductible
        recharge.litres_remaining = max(0, recharge.litres_allocated - recharge.litres_used)
        
        # Mark for filtration if running low
        if recharge.litres_remaining <= 50:
            recharge.needs_filtration = True
        
        # Mark as expired if fully consumed
        if recharge.litres_remaining <= 0:
            recharge.status = 'expired'
        
        recharge.save()
        
        # Reduce remaining usage
        remaining_usage -= deductible
    
    # Allow continuous usage - always return True
    return True
