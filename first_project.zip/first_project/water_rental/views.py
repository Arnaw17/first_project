from .models import SensorData, Customer
from django.utils import timezone
from datetime import timedelta
from django.contrib.auth.decorators import login_required
from openpyxl import Workbook
from django.http import HttpResponse
from django.db import models
from django.shortcuts import render, redirect
from django.views.generic import ListView, DetailView
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.middleware.csrf import get_token
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone as django_timezone
from django.views.decorators.http import require_http_methods
from decimal import Decimal
import random
import json
from .models import (WaterQualityReading,
                     Customer, WaterUsage, Recharge, Payment, UserComplain, Coupon, CouponUsage, Technician, SubscriptionPlan, CalibrationData)
from django.urls import reverse
from django.views.decorators.http import require_http_methods
import time
import hmac
import hashlib
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.views.decorators.csrf import csrf_exempt
from .serializers import (
    SensorBatchSerializer, SensorDataSerializer, DailyConsumptionSerializer,
    MonthlyConsumptionSerializer, ProvisionDeviceSerializer, CheckOTASerializer,
    CustomerRegistrationSerializer, CustomerLoginSerializer, CustomerProfileSerializer,
    CustomerInfoSerializer, CustomerLocationSerializer, CustomerWaterUsageSerializer,
    CustomerRechargeInfoSerializer, PaymentCreateSerializer, SubscriptionInfoSerializer,
    UserComplainCustomerSerializer, UserComplainCreateSerializer,
    ESPBlockUnblockStatusSerializer, ESPOTAStatusCheckSerializer, ESPSensorDataSerializer,
    ESPDeviceHealthSerializer, ESPCalibrationFactorSerializer, FCMTokenSerializer
) 

from .utils import get_device_token
from .tasks import save_sensor_batch, save_sensor_data

"""=============start of the page views===================="""
"""when running the server redirect to admin login if not logged in and if logged in redirect to admin dashboard"""

def landing_page(request):
    """Landing page - redirects to appropriate page based on auth status"""
    # If user is authenticated, redirect to admin dashboard
    if request.user.is_authenticated:
        return redirect('aquaguard:admin-dashboard')
    # If not authenticated, redirect to login
    return redirect('aquaguard:admin-login')

"""Start of Admin  Views"""
"""================Adming Login/Signup Function============================="""

# Authentication for admin 

#check login credentials and authenticate admin


def admin_login(request):
    """Admin login view"""
    if request.user.is_authenticated:
        return redirect('aquaguard:admin-dashboard')
    
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        remember_me = request.POST.get('remember_me')
        
        try:
            # Get the first user with this email (in case of duplicates)
            user = User.objects.filter(email=email).first()
            if not user:
                messages.error(request, 'No account found with this email. Please sign up first.')
                return render(request, 'aquaguard/admin_login.html')
            
            authenticated_user = authenticate(request, username=user.username, password=password)
            
            if authenticated_user is not None:
                login(request, authenticated_user)
                
                # Handle Remember Me functionality
                if remember_me:
                    # Session expires after 30 days
                    request.session.set_expiry(2592000)  # 30 days in seconds
                else:
                    # Session expires when browser closes
                    request.session.set_expiry(0)
                
                messages.success(request, f'Welcome back, {authenticated_user.username}!')
                
                # Redirect to next parameter or admin dashboard
                next_url = request.GET.get('next', 'aquaguard:admin-dashboard')
                if next_url.startswith('/'):
                    return redirect(next_url)
                return redirect(next_url)
            else:
                messages.error(request, 'Incorrect password. Please try again.')
        except Exception as e:
            messages.error(request, f'Login error: {str(e)}')
    
    return render(request, 'aquaguard/admin_login.html')

"""================Admin Signup with OTP Verification============================="""

def admin_signup(request):
    """Admin signup view with OTP verification"""
    if request.user.is_authenticated:
        return redirect('aquaguard:admin-dashboard')
    
    if request.method == 'POST':
        action = request.POST.get('action', 'send_otp')
        
        if action == 'send_otp':
            # Step 1: Send OTP to email
            username = request.POST.get('username')
            email = request.POST.get('email')
            password = request.POST.get('password')
            password_confirm = request.POST.get('password_confirm')
            
            # Validation
            if not all([username, email, password, password_confirm]):
                messages.error(request, 'All fields are required.')
                return render(request, 'aquaguard/admin_signup.html')
            
            if password != password_confirm:
                messages.error(request, 'Passwords do not match.')
                return render(request, 'aquaguard/admin_signup.html')
            
            if len(password) < 8:
                messages.error(request, 'Password must be at least 8 characters long.')
                return render(request, 'aquaguard/admin_signup.html')
            
            if User.objects.filter(username=username).exists():
                messages.error(request, 'Username already exists.')
                return render(request, 'aquaguard/admin_signup.html')
            
            if User.objects.filter(email=email).exists():
                messages.error(request, 'Email already registered.')
                return render(request, 'aquaguard/admin_signup.html')
            
            # Generate 6-digit OTP
            otp = str(random.randint(100000, 999999))
            
            # Store data in session
            request.session['admin_signup_data'] = {
                'username': username,
                'email': email,
                'password': password,
                'otp': otp
            }
            
            # Send OTP via email
            try:
                send_mail(
                    subject='AquaGuard Admin - Email Verification OTP',
                    message=f'''Hello {username},

Your OTP for AquaGuard Admin signup is: {otp}

This OTP is valid for 10 minutes.

If you did not request this, please ignore this email.

Best regards,
AquaGuard Admin Team''',
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    recipient_list=[email],
                    fail_silently=False,
                )
                messages.success(request, f"OTP has been sent to {email}. Please check your inbox.")
                return render(request, 'aquaguard/admin_signup.html', {'show_otp_field': True})
            except Exception as e:
                messages.error(request, f"Failed to send OTP: {str(e)}")
                return render(request, 'aquaguard/admin_signup.html')
        
        elif action == 'verify_otp':
            # Step 2: Verify OTP and create account
            entered_otp = request.POST.get('otp', '')
            signup_data = request.session.get('admin_signup_data')
            
            if not signup_data:
                messages.error(request, "Session expired. Please start again.")
                return render(request, 'aquaguard/admin_signup.html')
            
            if entered_otp != signup_data.get('otp'):
                messages.error(request, "Invalid OTP. Please try again.")
                return render(request, 'aquaguard/admin_signup.html', {'show_otp_field': True})
            
            # OTP verified, create account
            try:
                username = signup_data['username']
                email = signup_data['email']
                password = signup_data['password']
                
                # Create admin user
                user = User.objects.create_user(
                    username=username,
                    email=email,
                    password=password,
                    is_staff=True  # Make user staff
                )
                user.save()
                
                # Send credentials via email
                try:
                    send_mail(
                        subject='AquaGuard Admin - Account Created Successfully',
                        message=f'''Hello {username},

Your AquaGuard Admin account has been created successfully!

Your Admin Login Credentials:
━━━━━━━━━━━━━━━━━━━━━━━━
Username: {username}
Email: {email}
Password: {password}
━━━━━━━━━━━━━━━━━━━━━━━━

You can now login to your admin account at: http://127.0.0.1:8000/admin-login/

Please keep these credentials safe and change your password after first login.

Thank you for joining AquaGuard!

Best regards,
AquaGuard Admin Team''',
                        from_email=settings.DEFAULT_FROM_EMAIL,
                        recipient_list=[email],
                        fail_silently=False,
                    )
                except Exception as e:
                    print(f"Email sending failed: {e}")
                
                # Clear session data
                del request.session['admin_signup_data']
                
                messages.success(request, 'Admin account created successfully! Login credentials have been sent to your email.')
                return redirect('aquaguard:admin-login')
            
            except Exception as e:
                messages.error(request, f'Error creating account: {str(e)}')
                return render(request, 'aquaguard/admin_signup.html')
    
    return render(request, 'aquaguard/admin_signup.html')

"""================Admin Logout Function============================="""

def admin_logout(request):
    """Admin logout view"""
    logout(request)
    messages.success(request, 'You have been logged out successfully.')
    return redirect('aquaguard:admin-login')


"""================Admin Dashboard Function============================="""

@login_required
def admin_dashboard(request):
    """Admin dashboard showing customer overview"""
    customers = Customer.objects.all()
    search_query = request.GET.get('search', '').strip()
    
    # Apply search filter
    if search_query:
        from django.db.models import Q
        customers = customers.filter(
            Q(name__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(phone_number__icontains=search_query) |
            Q(device_chip_id__icontains=search_query) |
            Q(customer_address__icontains=search_query)
        )
    
    # Enrich customer data with active recharge info and latest pending edit request
    from .models import ProfileEditRequest
    customer_list = []
    for customer in customers:
        active_recharge = Recharge.objects.filter(customer=customer, status='active').first()
        # Get latest pending edit request for this customer (if any)
        latest_edit_request = ProfileEditRequest.objects.filter(customer=customer, status='pending').order_by('-requested_at').first()
        # Use robust model property for price per litre
        price_per_litre = customer.paisa_per_litre
        customer_data = {
            'customer': customer,
            'active_recharge': active_recharge,
            'litres_remaining': active_recharge.litres_remaining if active_recharge else 0,
            'price_per_litre': price_per_litre,
            'edit_request_id': latest_edit_request.id if latest_edit_request else None,
        }
        customer_list.append(customer_data)
    
    context = {
        'total_customers': Customer.objects.all().count(),
        'online_devices': Customer.objects.filter(device_status='online').count(),
        'offline_devices': Customer.objects.filter(device_status='offline').count(),
        'customers': customer_list,
        'search_query': search_query,
    }
    return render(request, 'aquaguard/admin_dashboard.html', context)


"""================Customer Details View function============================="""

@login_required
def customer_details(request, customer_id):
    """Show detailed customer information with device and usage data"""
    from django.utils import timezone
    from django.db.models import Sum
    from datetime import datetime
    customer = Customer.objects.get(id=customer_id)
    usages = WaterUsage.objects.filter(customer=customer).order_by('-usage_date')
    recharges = Recharge.objects.filter(customer=customer).order_by('-recharge_date')
    payments = Payment.objects.filter(customer=customer).order_by('-recharge_date')
    
    # Get today's usage specifically for real-time display
    today = timezone.now().date()
    today_usage = WaterUsage.objects.filter(customer=customer, usage_date=today).first()

    usage_metrics = {
        'last_day_usage': 0.0,
        'today_usage': 0.0,
        'monthly_total_usage': 0.0,
        'monthly_average_usage': 0.0,
    }

    if today_usage and today_usage.current_day_usage is not None:
        usage_metrics['today_usage'] = float(today_usage.current_day_usage)

    yesterday = today - timedelta(days=1)
    yesterday_usage = WaterUsage.objects.filter(customer=customer, usage_date=yesterday).first()
    if yesterday_usage:
        daily_value = yesterday_usage.current_day_usage or yesterday_usage.last_24hr_usage or 0
        usage_metrics['last_day_usage'] = float(daily_value)

    month_window_start = today - timedelta(days=30)
    month_usages = WaterUsage.objects.filter(customer=customer, usage_date__gte=month_window_start, usage_date__lte=today)
    month_total = month_usages.aggregate(total=Sum('current_day_usage'))['total'] or 0
    month_total_value = float(month_total) if month_total else 0.0
    usage_metrics['monthly_total_usage'] = month_total_value
    if month_total_value:
        usage_metrics['monthly_average_usage'] = month_total_value / 30.0
    
    # Calculate totals across all active recharges
    active_recharges = recharges.filter(status='active')
    active_recharge_data = None
    if active_recharges.exists():
        totals = active_recharges.aggregate(
            total_allocated=Sum('litres_allocated'),
            total_used=Sum('litres_used'),
            total_remaining=Sum('litres_remaining')
        )
        # Get the earliest expiry date from active recharges
        earliest_expiry = active_recharges.order_by('expiry_date').first()
        active_recharge_data = {
            'litres_allocated': totals['total_allocated'],
            'litres_used': totals['total_used'],
            'litres_remaining': totals['total_remaining'],
            'days_until_expiry': earliest_expiry.days_until_expiry if earliest_expiry else 0,
        }
    
    # Get tracked location data
    tracked_location = None
    # Use only actual latitude/longitude/location fields
    latitude = customer.latitude
    longitude = customer.longitude
    location_name = customer.location or customer.customer_address or 'Unknown location'
    
    # Determine last updated time - use location update time if available, otherwise last recharge
    last_updated = customer.last_recharge_date or 'Not available'
    
    if latitude and longitude:
        tracked_location = {
            'latitude': latitude,
            'longitude': longitude,
            'location_name': location_name,
            'last_updated': last_updated,
            'has_resolved_location': bool(customer.location and customer.location != 'Unknown location')
        }
    
    from .models import ProfileEditRequest, CalibrationData
    latest_edit_request = ProfileEditRequest.objects.filter(customer=customer, status='pending').order_by('-requested_at').first()
    calibration_data = CalibrationData.objects.filter(customer=customer).order_by('-recorded_at')
    
    # Get latest sensor data for pH, TDS, water_quality, device_health
    from .models import SensorData
    latest_sensor = SensorData.objects.filter(customer=customer).order_by('-esp_timestamp').first()
    sensor_info = None
    if latest_sensor:
        sensor_info = {
            'ph': latest_sensor.ph,
            'tds': latest_sensor.tds,
            'water_quality': latest_sensor.water_quality,
            'device_health': latest_sensor.device_health,
            'flow_rate': latest_sensor.current_volume,
            'total_flow': latest_sensor.total_volume,
            'timestamp': latest_sensor.esp_timestamp,
        }
    
    context = {
        'customer': customer,
        'usages': usages,
        'recharges': recharges,
        'payments': payments,
        'last_usage': today_usage if today_usage else (usages.first() if usages.exists() else None),
        'usage_metrics': usage_metrics,
        'active_recharge': active_recharge_data,
        'active_recharge_breakdown': customer.paisa_per_litre_details,
        'tracked_location': tracked_location,
        'edit_request_id': latest_edit_request.id if latest_edit_request else None,
        'calibration_data': calibration_data,
        'customer_type_choices': Customer.CUSTOMER_TYPE_CHOICES,
        'board_options': BOARD_OPTIONS,
        'sensor_info': sensor_info,
    }
    return render(request, 'aquaguard/customer_details.html', context)

"""================Customer List View Class for in customer list============================="""


class CustomerListView(ListView):
    """List all customers"""
    model = Customer
    template_name = 'aquaguard/customer_list.html'
    context_object_name = 'customers'
    paginate_by = 20
    ordering = ['-registration_date']
    
    def get_queryset(self):
        queryset = super().get_queryset()
        search_query = self.request.GET.get('search', '').strip()
        
        if search_query:
            # Search by name, email, phone, device ID, or address
            from django.db.models import Q
            queryset = queryset.filter(
                Q(name__icontains=search_query) |
                Q(email__icontains=search_query) |
                Q(phone_number__icontains=search_query) |
                Q(device_chip_id__icontains=search_query) |
                Q(customer_address__icontains=search_query)
            )
        
        return queryset
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['search_query'] = self.request.GET.get('search', '')
        return context

"""================Sensor Data Dashboard View function============================="""

@login_required
def sensor_data_dashboard(request):
    """Dashboard showing sensor data with usage calculations"""
    from .models import SensorData
    from django.db.models import Sum
    customers = Customer.objects.all()
    search_query = request.GET.get('search', '').strip()
    
    # Apply search filter
    if search_query:
        from django.db.models import Q
        customers = customers.filter(
            Q(name__icontains=search_query) |
            Q(email__icontains=search_query) |
            Q(device_chip_id__icontains=search_query) |
            Q(phone_number__icontains=search_query)
        )
    
    customers = list(customers)
    customer_ids = [c.id for c in customers]
    sensor_data = []
    
    # Build a map of latest WaterQualityReading per customer
    water_quality_map = {}
    for wqr in WaterQualityReading.objects.order_by('-reading_date'):
        if wqr.customer_id and wqr.customer_id not in water_quality_map:
            water_quality_map[wqr.customer_id] = wqr
    today = timezone.now().date()

    recharge_map = {}
    if customer_ids:
        recharge_totals = Recharge.objects.filter(
            customer_id__in=customer_ids,
            status='active'
        ).values('customer_id').annotate(
            total_allocated=Sum('litres_allocated'),
            total_used=Sum('litres_used')
        )
        recharge_map = {entry['customer_id']: entry for entry in recharge_totals}

    for customer in customers:
        latest_usage = WaterUsage.objects.filter(customer=customer).first()
        # Get latest sensor reading for pH, TDS, water_quality, device_health
        latest_sensor = SensorData.objects.filter(customer=customer).order_by('-esp_timestamp').first()
        if latest_usage:
            recharge_stats = recharge_map.get(customer.id, {})
            total_allocated = float(recharge_stats.get('total_allocated') or 0)
            total_used = float(recharge_stats.get('total_used') or 0)
            remaining_water = max(total_allocated - total_used, 0)

            recent_readings = list(
                SensorData.objects.filter(customer=customer).order_by('-esp_timestamp')[:5]
            )
            latest_reading = recent_readings[0] if recent_readings else None

            # Use current_volume as flow_rate since it's the instantaneous measurement
            flow_rate_value = latest_reading.current_volume if latest_reading else None

            current_day_usage = 0.0
            if latest_usage.usage_date == today and latest_usage.current_day_usage is not None:
                current_day_usage = float(latest_usage.current_day_usage)
            sensor_data.append({
                'customer': customer,
                'device_status': customer.device_status,
                'last_24hr_usage': latest_usage.last_24hr_usage,
                'monthly_usage': latest_usage.monthly_usage,
                'per_day_average': latest_usage.per_day_average,
                'current_day_usage': current_day_usage,
                'allocated_water': total_allocated,
                'flow_rate': flow_rate_value,
                'total_used_water': total_used,
                'remaining_water': remaining_water,
                'ph': latest_sensor.ph if latest_sensor else None,
                'tds': latest_sensor.tds if latest_sensor else None,
                'water_quality': latest_sensor.water_quality if latest_sensor else None,
                'device_health': latest_sensor.device_health if latest_sensor else customer.device_health,
            })
    
    context = {
        'sensor_data': sensor_data,
        'search_query': search_query,
    }
    return render(request, 'aquaguard/sensor_data_dashboard.html', context)


"""================Payment History View function============================="""


@login_required
def payment_history(request):
    """Display payment history for all customers"""
    from django.db.models import Sum, Q
    
    payments = Payment.objects.all().order_by('-recharge_date')
    search_query = request.GET.get('search', '').strip()
    
    # Apply search filter
    if search_query:
        payments = payments.filter(
            Q(customer__name__icontains=search_query) |
            Q(customer__email__icontains=search_query) |
            Q(customer__phone_number__icontains=search_query) |
            Q(transaction_id__icontains=search_query) |
            Q(payment_status__icontains=search_query)
        )
    
    completed_payments = payments.filter(payment_status='completed')
    pending_payments = payments.filter(payment_status='pending')
    total_revenue = completed_payments.aggregate(Sum('amount'))['amount__sum'] or 0
    completed_count = completed_payments.count()
    pending_count = pending_payments.count()
    
    context = {
        'payments': payments,
        'total_revenue': total_revenue,
        'completed_count': completed_count,
        'pending_count': pending_count,
        'search_query': search_query,
    }
    return render(request, 'aquaguard/payment_history.html', context)

"""================Customer Search View function============================="""

@login_required
def customer_search(request):
    """Search customers by name, email, or phone number (case-insensitive)"""
    query = request.GET.get('query', '').strip()
    search_by = request.GET.get('search_by', 'name')
    
    customers = []
    search_type = ''
    customer_data = []
    
    if query:
        # Capitalize query for proper comparison
        query_capitalized = query.title()  # Capitalizes each word
        
        if search_by == 'name':
            # Case-insensitive search using icontains
            customers = Customer.objects.filter(name__icontains=query)
            search_type = 'Name'
        elif search_by == 'email':
            # Case-insensitive search for email
            customers = Customer.objects.filter(email__icontains=query)
            search_type = 'Email'
        elif search_by == 'phone':
            # Phone search doesn't need case handling
            customers = Customer.objects.filter(phone_number__icontains=query)
            search_type = 'Phone'
        
        # Get additional data for each customer
        for customer in customers:
            latest_usage = WaterUsage.objects.filter(customer=customer).first()
            latest_recharge = Recharge.objects.filter(customer=customer).order_by('-recharge_date').first()
            
            customer_data.append({
                'customer': customer,
                'last_24hr_usage': latest_usage.last_24hr_usage if latest_usage else 0,
                'last_recharge': latest_recharge,
            })
    
    context = {
        'customer_data': customer_data,
        'query': query,
        'search_by': search_by,
        'search_type': search_type,
    }
    return render(request, 'aquaguard/customer_search.html', context)


"""================Toggle Block/Unblock function============================="""


@login_required
@require_POST
def toggle_block_unblock(request, customer_id):
    """Toggle block/unblock status for a customer"""
    from django.core.mail import send_mail
    try:
        customer = Customer.objects.get(id=customer_id)
        old_status = customer.block_unblock
        customer.block_unblock = not customer.block_unblock
        customer.save()
        
        status = '🟢 Active' if customer.block_unblock else '🔴 Blocked'
        
        # Send notification to customer if blocked
        if not customer.block_unblock and old_status:
            try:
                send_mail(
                    'Your Water Machine is Blocked',
                    f'Dear {customer.name},\n\nYour water machine has been blocked by the administrator. Please contact support for more information.\n\nRegards,\nAquaGuard Team',
                    settings.DEFAULT_FROM_EMAIL,
                    [customer.email],
                    fail_silently=True
                )
            except Exception as e:
                logger.error(f"Failed to send block notification to {customer.email}: {e}")
        
        return JsonResponse({
            'success': True,
            'block_unblock': customer.block_unblock,
            'status': status,
            'message': f"Customer {customer.name} is now {status}"
        })
    except Customer.DoesNotExist:
        return JsonResponse({
            'success': False,
            'message': 'Customer not found'
        }, status=404)
    except Exception as e:
        return JsonResponse({
            'success': False,
            'message': str(e)
        }, status=500)



"""================Business Alerts View function============================="""


@login_required
def business_alerts_view(request):
    """Display business alerts for admin"""
    from .business_alerts import get_all_business_alerts, get_alert_summary
    
    alerts = get_all_business_alerts()
    summary = get_alert_summary()
    search_query = request.GET.get('search', '').strip()
    
    # Apply search filter
    if search_query:
        search_lower = search_query.lower()
        alerts = [alert for alert in alerts if 
                 search_lower in alert.customer.name.lower() or
                 search_lower in alert.customer.email.lower() or
                 search_lower in alert.customer.phone_number.lower() or
                 search_lower in alert.alert_type.lower() or
                 search_lower in alert.message.lower() or
                 search_lower in alert.severity.lower()]
    
    context = {
        'alerts': alerts,
        'summary': summary,
        'search_query': search_query,
    }
    return render(request, 'aquaguard/business_alerts.html', context)


@login_required
def dismiss_alert(request, customer_id, alert_type):
    """Dismiss a specific alert"""
    try:
        from .models import DismissedAlert
        
        customer = Customer.objects.get(id=customer_id)
        
        # Create or update dismissed alert
        dismissed, created = DismissedAlert.objects.get_or_create(
            customer=customer,
            alert_type=alert_type,
            defaults={'dismissed_by': request.user}
        )
        
        return JsonResponse({
            'status': 'success',
            'message': f'Alert dismissed for {customer.name}',
            'alert_type': alert_type
        })
    except Customer.DoesNotExist:
        return JsonResponse({
            'status': 'error',
            'message': 'Customer not found'
        }, status=404)
    except Exception as e:
        return JsonResponse({
            'status': 'error',
            'message': f'Database not ready. Please run migrations first: {str(e)}'
        }, status=500)


@login_required
def restore_alert(request, customer_id, alert_type):
    """Restore a dismissed alert"""
    try:
        from .models import DismissedAlert
        
        customer = Customer.objects.get(id=customer_id)
        DismissedAlert.objects.filter(
            customer=customer,
            alert_type=alert_type
        ).delete()
        
        return JsonResponse({
            'status': 'success',
            'message': f'Alert restored for {customer.name}'
        })
    except Exception as e:
        return JsonResponse({
            'status': 'error',
            'message': str(e)
        }, status=500)


@login_required
def get_alerts_json(request):
    """API endpoint to get alerts as JSON for real-time updates"""
    from .business_alerts import get_all_business_alerts, get_alert_summary
    
    alerts = get_all_business_alerts()
    summary = get_alert_summary()
    
    alerts_data = []
    for alert in alerts:
        alerts_data.append({
            'customer_id': alert.customer.id,
            'customer_name': alert.customer.name,
            'alert_type': alert.alert_type,
            'severity': alert.severity,
            'message': alert.message,
            'details': alert.details,
        })
    
    return JsonResponse({
        'alerts': alerts_data,
        'summary': summary,
        'timestamp': django_timezone.now().isoformat()
    })





# ========== TECHNICIAN MANAGEMENT VIEWS ========== 

BOARD_OPTIONS = [('esp32', 'ESP32'), ('esp8266', 'ESP8266')]
BOARD_OPTION_VALUES = {value for value, _ in BOARD_OPTIONS}
@login_required
def technician_list(request):
    technicians = Technician.objects.all()
    context = {'technicians': technicians}
    return render(request, 'aquaguard/technician_list.html', context)

@login_required
@require_http_methods(["GET", "POST"])
def add_technician(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone_number = request.POST.get('phone_number')
        specialization = request.POST.get('specialization')
        area_of_operation = request.POST.get('area_of_operation')
        rating = request.POST.get('rating') or 0
        completed_jobs = request.POST.get('completed_jobs') or 0
        status = request.POST.get('status') or 'available'
        is_active = bool(request.POST.get('is_active'))
        Technician.objects.create(
            name=name,
            email=email,
            phone_number=phone_number,
            specialization=specialization,
            area_of_operation=area_of_operation,
            rating=rating,
            completed_jobs=completed_jobs,
            status=status,
            is_active=is_active
        )
        return redirect('aquaguard:technician-list')
    return render(request, 'aquaguard/add_technician.html')

#edit technician details

@login_required
@require_http_methods(["GET", "POST"])
def edit_technician(request, technician_id):
    technician = Technician.objects.get(id=technician_id)
    if request.method == "POST":
        technician.name = request.POST.get('name')
        technician.email = request.POST.get('email')
        technician.phone_number = request.POST.get('phone_number')
        technician.specialization = request.POST.get('specialization')
        technician.area_of_operation = request.POST.get('area_of_operation')
        technician.rating = request.POST.get('rating') or 0
        technician.completed_jobs = request.POST.get('completed_jobs') or 0
        technician.status = request.POST.get('status') or 'available'
        technician.is_active = bool(request.POST.get('is_active'))
        technician.save()
        return redirect('aquaguard:technician-list')
    context = {'technician': technician}
    return render(request, 'aquaguard/edit_technician.html', context)

#delete technician

@login_required
def delete_technician(request, technician_id):
    technician = Technician.objects.get(id=technician_id)
    technician.delete()
    return redirect('aquaguard:technician-list')

#view technician details

@login_required
def technician_detail(request, technician_id):
    technician = Technician.objects.get(id=technician_id)
    context = {'technician': technician}
    return render(request, 'aquaguard/technician_detail.html', context)


# ========== SUBSCRIPTION PLAN MANAGEMENT ==========

@login_required
def admin_subscription_plans(request):
    """List all subscription plans with filters"""
    plans = SubscriptionPlan.objects.all().order_by('-created_at')
    
    # Filters
    status_filter = request.GET.get('status', '')
    search = request.GET.get('search', '')
    
    if status_filter:
        plans = plans.filter(status=status_filter)
    if search:
        plans = plans.filter(plan_name__icontains=search)
    
    context = {
        'plans': plans,
        'current_status': status_filter,
        'current_search': search,
    }
    return render(request, 'aquaguard/admin_subscription_plans.html', context)

#================Subscription Plan Detail View function============================="""

@login_required
def admin_subscription_plan_detail(request, plan_id):
    """View subscription plan details"""
    plan = SubscriptionPlan.objects.get(id=plan_id)
    
    # Get customers using this plan
    customers = Customer.objects.filter(subscription_plan=plan).select_related('subscription_plan')
    
    context = {
        'plan': plan,
        'customers': customers,
        'customer_count': customers.count(),
        'price_per_litre': plan.paisa_per_litre,
    }
    return render(request, 'aquaguard/admin_subscription_plan_detail.html', context)


#================Create Subscription Plan View function============================="""

@login_required
def admin_create_subscription_plan(request):
    """Create a new subscription plan"""
    if request.method == 'POST':
        try:
            plan_name = request.POST.get('plan_name', '').strip()
            description = request.POST.get('description', '').strip()
            price = request.POST.get('price', '')
            litres_allocated = request.POST.get('litres_allocated', '')
            duration_days = request.POST.get('duration_days', '30')
            is_popular = request.POST.get('is_popular') == 'on'
            status = request.POST.get('status') == 'true'
            features = request.POST.getlist('features[]')
            
            # Validation
            errors = []
            if not plan_name:
                errors.append('Plan name is required')
            if not price:
                errors.append('Price is required')
            if not litres_allocated:
                errors.append('Litres allocated is required')
            
            try:
                price = float(price)
                litres_allocated = int(litres_allocated)
                duration_days = int(duration_days)
            except ValueError:
                errors.append('Price must be a number, litres and days must be integers')
            
            if price <= 0:
                errors.append('Price must be greater than 0')
            if litres_allocated <= 0:
                errors.append('Litres allocated must be greater than 0')
            if duration_days <= 0:
                errors.append('Duration must be greater than 0')
            
            if errors:
                context = {
                    'errors': errors,
                    'form_data': request.POST,
                }
                return render(request, 'aquaguard/admin_create_subscription_plan.html', context)
            
            # Create plan
            plan = SubscriptionPlan.objects.create(
                plan_name=plan_name,
                description=description,
                price=price,
                litres_allocated=litres_allocated,
                duration_days=duration_days,
                is_popular=is_popular,
                status=status,
                description_features=features if features else [],
            )
            
            messages.success(request, f'✅ Subscription plan "{plan_name}" created successfully!')
            return redirect('aquaguard:subscription-plans')
            
        except Exception as e:
            messages.error(request, f'❌ Error creating plan: {str(e)}')
            return redirect('aquaguard:subscription-plans')
    
    context = {
    }
    return render(request, 'aquaguard/admin_create_subscription_plan.html', context)


#================Update Subscription Plan View function============================="""

@login_required
def admin_update_subscription_plan(request, plan_id):
    """Update an existing subscription plan"""
    plan = SubscriptionPlan.objects.get(id=plan_id)
    
    if request.method == 'POST':
        try:
            plan_name = request.POST.get('plan_name', '').strip()
            description = request.POST.get('description', '').strip()
            price = request.POST.get('price', '')
            litres_allocated = request.POST.get('litres_allocated', '')
            duration_days = request.POST.get('duration_days', '30')
            is_popular = request.POST.get('is_popular') == 'on'
            status = request.POST.get('status') == 'true'
            features = request.POST.getlist('features[]')
            
            # Validation
            errors = []
            if not plan_name:
                errors.append('Plan name is required')
            if not price:
                errors.append('Price is required')
            if not litres_allocated:
                errors.append('Litres allocated is required')
            
            try:
                price = float(price)
                litres_allocated = int(litres_allocated)
                duration_days = int(duration_days)
            except ValueError:
                errors.append('Price must be a number, litres and days must be integers')
            
            if price <= 0:
                errors.append('Price must be greater than 0')
            if litres_allocated <= 0:
                errors.append('Litres allocated must be greater than 0')
            if duration_days <= 0:
                errors.append('Duration must be greater than 0')
            
            if errors:
                context = {
                    'plan': plan,
                    'errors': errors,
                    'form_data': request.POST,
                }
                return render(request, 'aquaguard/admin_update_subscription_plan.html', context)
            
            # Update plan
            plan.plan_name = plan_name
            plan.description = description
            plan.price = price
            plan.litres_allocated = litres_allocated
            plan.duration_days = duration_days
            plan.is_popular = is_popular
            plan.status = status
            plan.description_features = features if features else []
            plan.save()
            
            messages.success(request, f'✅ Subscription plan "{plan_name}" updated successfully!')
            return redirect('aquaguard:subscription-plan-detail', plan_id=plan.id)
            
        except Exception as e:
            messages.error(request, f'❌ Error updating plan: {str(e)}')
            return redirect('aquaguard:subscription-plan-detail', plan_id=plan.id)
    
    context = {
        'plan': plan,
    }
    return render(request, 'aquaguard/admin_update_subscription_plan.html', context)


#================Delete Subscription Plan View function============================="""

@login_required
@require_http_methods(["POST"])
def admin_delete_subscription_plan(request, plan_id):
    """Delete a subscription plan"""
    try:
        plan = SubscriptionPlan.objects.get(id=plan_id)
        plan_name = plan.plan_name
        
        # Check if any customers are using this plan
        customer_count = plan.customer_set.count()
        if customer_count > 0:
            messages.warning(request, f'⚠️ Cannot delete plan "{plan_name}" - {customer_count} customer(s) are using it. Remove customers first.')
            return redirect('aquaguard:subscription-plan-detail', plan_id=plan.id)
        
        plan.delete()
        messages.success(request, f'✅ Subscription plan "{plan_name}" deleted successfully!')
        return redirect('aquaguard:subscription-plans')
        
    except SubscriptionPlan.DoesNotExist:
        messages.error(request, '❌ Plan not found')
        return redirect('aquaguard:subscription-plans')
    except Exception as e:
        messages.error(request, f'❌ Error deleting plan: {str(e)}')
        return redirect('aquaguard:subscription-plans')
    

#================User Complaints Management Views============================="""


@login_required
def admin_complaints_list(request):
    """Display all user complaints with filtering and search"""
    complaints = UserComplain.objects.all().order_by('-complain_date')
    search_query = request.GET.get('search', '').strip()
    status_filter = request.GET.get('status', '')
    priority_filter = request.GET.get('priority', '')
    overdue_filter = request.GET.get('overdue', '')
    
    if search_query:
        from django.db.models import Q
        complaints = complaints.filter(
            Q(customer__name__icontains=search_query) |
            Q(phone_no__icontains=search_query) |
            Q(device_id__icontains=search_query) |
            Q(problem_statement__icontains=search_query) |
            Q(future_field1__icontains=search_query)
        )
    
    if status_filter:
        complaints = complaints.filter(status=status_filter)
    
    if priority_filter:
        complaints = complaints.filter(priority=priority_filter)
    
    if overdue_filter:
        complaints = complaints.filter(
            status__in=['open', 'pending'],
            complain_date__lt=django_timezone.now() - django_timezone.timedelta(days=7)
        )
    
    # Calculate counts
    all_complaints = UserComplain.objects.all()
    open_count = all_complaints.filter(status='open').count()
    in_progress_count = all_complaints.filter(status='in_progress').count()
    resolved_count = all_complaints.filter(status='resolved').count()
    closed_count = all_complaints.filter(status='closed').count()
    overdue_count = all_complaints.filter(
        status__in=['open', 'pending'],
        complain_date__lt=django_timezone.now() - django_timezone.timedelta(days=7)
    ).count()
    
    # Ensure future_field1 and future_field2 are set for display
    for complaint in complaints:
        # Skip data migration since future_field1 is now the primary email storage
        if complaint.closed_date and (not complaint.future_field2 or complaint.future_field2 == ''):
            complaint.future_field2 = complaint.closed_date.strftime('%Y-%m-%d %H:%M')
            complaint.save(update_fields=['future_field2'])

    context = {
        'complaints': complaints,
        'total_complaints': all_complaints.count(),
        'open_count': open_count,
        'in_progress_count': in_progress_count,
        'resolved_count': resolved_count,
        'closed_count': closed_count,
        'overdue_count': overdue_count,
        'search_query': search_query,
        'status_filter': status_filter,
        'priority_filter': priority_filter,
    }
    return render(request, 'aquaguard/admin_complaints_list.html', context)

#================User Complaint Detail View function============================="""


@login_required
def admin_complaint_detail(request, complaint_id):
    """Display and manage a specific complaint"""
    complaint = UserComplain.objects.get(id=complaint_id)
    
    if request.method == 'POST':
        action = request.POST.get('action')

        if action == 'assign':
            assigned_technician_id = request.POST.get('assigned_to')
            if assigned_technician_id:
                from .models import Technician
                assigned_technician = Technician.objects.get(id=assigned_technician_id)
                complaint.assigned_person = assigned_technician
                complaint.assigned_person_details = request.POST.get('notes', '')
                complaint.assigned_at = django_timezone.now()
                complaint.status = 'in_progress'
                complaint.save()
                messages.success(request, f'Complaint assigned to {assigned_technician.name}')

        elif action == 'resolve':
            complaint.status = 'resolved'
            complaint.resolution_notes = request.POST.get('notes', '')
            complaint.save()
            messages.success(request, 'Complaint marked as resolved')

        elif action == 'close':
            complaint.status = 'closed'
            complaint.closed_date = django_timezone.now()
            # Append closing note to resolution notes for history
            closing_note = request.POST.get('notes', '')
            if closing_note:
                existing = complaint.resolution_notes or ''
                complaint.resolution_notes = (existing + '\n' if existing else '') + closing_note
            complaint.save()
            messages.success(request, 'Complaint closed successfully')

        return redirect('aquaguard:admin-complaint-detail', complaint_id=complaint_id)

    from .models import Technician
    technicians = Technician.objects.all()

    context = {
        'complaint': complaint,
        'technicians': technicians,
    }
    return render(request, 'aquaguard/admin_complaint_detail.html', context)


#================User Complaints Dashboard View function============================="""

@login_required
def admin_complaints_dashboard(request):
    """Dashboard view for complaint statistics and analytics"""
    all_complaints = UserComplain.objects.all()
    total_complaints = all_complaints.count()
    
    open_count = all_complaints.filter(status='open').count()
    in_progress_count = all_complaints.filter(status='in_progress').count()
    resolved_count = all_complaints.filter(status='resolved').count()
    closed_count = all_complaints.filter(status='closed').count()
    
    status_breakdown = {
        'open': open_count,
        'in_progress': in_progress_count,
        'resolved': resolved_count,
        'closed': closed_count,
        'pending': all_complaints.filter(status='pending').count(),
    }
    
    priority_breakdown = {
        'low': all_complaints.filter(priority='low').count(),
        'medium': all_complaints.filter(priority='medium').count(),
        'high': all_complaints.filter(priority='high').count(),
        'critical': all_complaints.filter(priority='critical').count(),
    }
    
    overdue_complaints = all_complaints.filter(
        status__in=['open', 'pending'],
        complain_date__lt=django_timezone.now() - django_timezone.timedelta(days=7)
    )
    
    recent_complaints = all_complaints.order_by('-complain_date')[:10]
    
    # Calculate resolution rate
    if total_complaints > 0:
        resolution_rate = int((closed_count / total_complaints) * 100)
    else:
        resolution_rate = 0
    
    context = {
        'total_complaints': total_complaints,
        'open_count': open_count,
        'in_progress_count': in_progress_count,
        'resolved_count': resolved_count,
        'closed_count': closed_count,
        'status_breakdown': status_breakdown,
        'priority_breakdown': priority_breakdown,
        'overdue_count': overdue_complaints.count(),
        'overdue_complaints': overdue_complaints,
        'recent_complaints': recent_complaints,
        'resolution_rate': resolution_rate,
    }
    return render(request, 'aquaguard/admin_complaints_dashboard.html', context)


#================Create User Complaint View function============================="""

@login_required
def admin_create_complaint(request):
    """Create a new complaint manually"""
    if request.method == 'POST':
        customer_id = request.POST.get('customer')
        phone_no = request.POST.get('phone_no', '').strip()
        device_id = request.POST.get('device_id', '').strip()
        problem_statement = request.POST.get('problem_statement', '').strip()
        priority = request.POST.get('priority', 'medium')
        status = request.POST.get('status', 'open')
        assigned_person_id = request.POST.get('assigned_person')

        # Validation
        if not customer_id:
            messages.error(request, 'Please select a customer')
            return redirect('aquaguard:admin-create-complaint')

        if not problem_statement:
            messages.error(request, 'Please provide a problem description')
            return redirect('aquaguard:admin-create-complaint')

        try:
            customer = Customer.objects.get(id=customer_id)
        except Customer.DoesNotExist:
            messages.error(request, 'Selected customer not found')
            return redirect('aquaguard:admin-create-complaint')

        # Create the complaint
        complaint = UserComplain.objects.create(
            customer=customer,
            phone_no=phone_no or customer.phone_number,
            device_id=device_id or customer.device_chip_id,
            problem_statement=problem_statement,
            priority=priority,
            status=status,
            future_field1=customer.email,  # Store email in future_field1
        )

        # Assign technician if selected
        if assigned_person_id:
            try:
                from .models import Technician
                technician = Technician.objects.get(id=assigned_person_id)
                complaint.assigned_person = technician
                complaint.assigned_at = django_timezone.now()
                if status == 'open':
                    complaint.status = 'in_progress'
                complaint.save()
            except Technician.DoesNotExist:
                pass  # Continue without assignment

        messages.success(request, f'Complaint created successfully! Ticket #{complaint.ticket_number}')
        return redirect('aquaguard:admin-complaint-detail', complaint_id=complaint.id)

    # GET request - show form
    from .models import Technician
    technicians = Technician.objects.filter(is_active=True)

    context = {
        'technicians': technicians,
    }
    return render(request, 'aquaguard/admin_create_complaint.html', context)



"""================Export Customers Data to Excel View function============================="""

@login_required
def export_customers_excel(request):
    """Export all customer details to Excel file (.xlsx)"""
    from datetime import datetime
    customers = Customer.objects.all()
    wb = Workbook()
    ws = wb.active
    ws.title = "Customers"
    # Header row
    ws.append([
        'Customer ID', 'Name', 'Email', 'Phone', 'Device ID', 'Current Plan', 'Current Plan Price',
        'Last Recharge Date', 'Registration Date', 'Status', 'Location', 'Customer Address',
        'Latitude', 'Longitude', 'Block Status'
    ])
    # Data rows
    for customer in customers:
        plan_name = customer.subscription_plan.plan_name if customer.subscription_plan else ''
        ws.append([
            str(customer.id),
            customer.name,
            customer.email,
            customer.phone_number,
            customer.device_chip_id,
            plan_name,
            customer.paisa_per_litre,
            customer.last_recharge_date.strftime('%Y-%m-%d %H:%M:%S') if customer.last_recharge_date else '',
            customer.registration_date.strftime('%Y-%m-%d %H:%M:%S') if customer.registration_date else '',
            'Active' if customer.block_unblock else 'Blocked',
            customer.location if customer.location else '',
            customer.customer_address if customer.customer_address else '',
            customer.latitude if customer.latitude else '',
            customer.longitude if customer.longitude else '',
            'No' if customer.block_unblock else 'Yes'
        ])
    # Prepare response
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    filename = f"customers_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    wb.save(response)
    return response

"""================Export Sensor Data to CSV View function============================="""

@login_required
def export_sensor_data_csv(request):
    """Export all sensor/water quality data to CSV file"""
    import csv
    from django.http import HttpResponse
    from datetime import datetime
    
    try:
        from .models import SensorData, Customer
        from django.utils import timezone
        from datetime import timedelta
        from django.http import HttpResponse
        import openpyxl
        from openpyxl.utils import get_column_letter

        # Get all per-second sensor data
        readings = SensorData.objects.select_related('customer').all().order_by('-esp_timestamp')
        # Build a map of latest WaterQualityReading per customer (keyed by customer UUID)
        water_quality_map = {}
        for wqr in WaterQualityReading.objects.order_by('-reading_date'):
            if wqr.customer_id and wqr.customer_id not in water_quality_map:
                water_quality_map[wqr.customer_id] = wqr

        # Precompute per-customer usage for last 24hr, week, month, year using WaterUsage model
        now = timezone.now().date()
        usage_24hr = {}
        usage_week = {}
        usage_month = {}
        usage_year = {}
        from .models import WaterUsage
        for customer in Customer.objects.all():
            cid = customer.email
            # Last 24hr usage: get the latest WaterUsage for today
            wu_24hr = WaterUsage.objects.filter(customer=customer, usage_date=now).order_by('-usage_date').first()
            usage_24hr[cid] = wu_24hr.last_24hr_usage if wu_24hr else 0
            # Last 7 days usage: sum last 7 days
            wu_week = WaterUsage.objects.filter(customer=customer, usage_date__gte=now - timedelta(days=6), usage_date__lte=now)
            usage_week[cid] = sum(wu.last_24hr_usage for wu in wu_week) if wu_week else 0
            # Last 30 days usage: sum last 30 days
            wu_month = WaterUsage.objects.filter(customer=customer, usage_date__gte=now - timedelta(days=29), usage_date__lte=now)
            usage_month[cid] = sum(wu.last_24hr_usage for wu in wu_month) if wu_month else 0
            # Last 365 days usage: sum last 365 days
            wu_year = WaterUsage.objects.filter(customer=customer, usage_date__gte=now - timedelta(days=364), usage_date__lte=now)
            usage_year[cid] = sum(wu.last_24hr_usage for wu in wu_year) if wu_year else 0

        # Create Excel workbook and worksheet
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Sensor Data"

        # Write header row
        headers = [
            'ID', 'Customer Name', 'Customer Email', 'Device Chip ID', 'Total Flow (L)',
            'pH', 'TDS (ppm)', 'Water Quality', 'Timestamp', 'Date',
            'Litres Used (24hr)', 'Litres Used (Week)', 'Litres Used (Month)', 'Litres Used (Year)'
        ]
        ws.append(headers)

        # Write per-second sensor data rows (with per-reading increment)
        # Build a dict to track previous total_flow for each customer per day
        prev_total_flow = {}
        for reading in readings:
            customer_email = reading.customer.email if reading.customer else None
            customer_uuid = reading.customer.id if reading.customer else None
            date_key = (customer_email, reading.esp_timestamp.date())
            prev = prev_total_flow.get(date_key, None)
            if prev is not None:
                increment = reading.total_volume - prev
                if increment < 0:
                    increment = 0
            else:
                increment = reading.total_volume
            prev_total_flow[date_key] = reading.total_volume
            import pytz
            kolkata = pytz.timezone('Asia/Kolkata')
            local_timestamp = reading.esp_timestamp.astimezone(kolkata) if reading.esp_timestamp else None
            # Use pH, TDS, water_quality directly from SensorData reading
            ws.append([
                reading.id,
                reading.customer.name if reading.customer else '',
                customer_email or '',
                reading.customer.device_chip_id if reading.customer else '',
                reading.total_volume,
                reading.ph if reading.ph is not None else '',
                reading.tds if reading.tds is not None else '',
                reading.water_quality or '',
                local_timestamp.strftime('%Y-%m-%d %H:%M:%S') if local_timestamp else '',
                reading.esp_timestamp.date().strftime('%Y-%m-%d') if reading.esp_timestamp else '',
                round(reading.total_volume, 3),
            ])
        # Optionally, update headers to reflect the change
        ws.delete_rows(1)
        headers = [
            'ID', 'Customer Name', 'Customer Email', 'Device Chip ID', 'Total Flow (L)',
            'pH', 'TDS (ppm)', 'Water Quality', 'Timestamp', 'Date',
            'Total Water Consumed (L)'
        ]
        ws.insert_rows(1)
        for col_num, header in enumerate(headers, 1):
            ws.cell(row=1, column=col_num, value=header)

        # Auto-adjust column widths
        for col in ws.columns:
            max_length = 0
            column = get_column_letter(col[0].column)
            for cell in col:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            ws.column_dimensions[column].width = max_length + 2

        # Create HTTP response with Excel content type
        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        filename = f"sensor_data_export_{now.strftime('%Y%m%d_%H%M%S')}.xlsx"
        response['Content-Disposition'] = f'attachment; filename="{filename}"'
        wb.save(response)
        messages.success(request, f"Exported {readings.count()} per-second sensor records with per-customer usage stats (Excel)")
        return response

    except Exception as e:
        import logging
        logger = logging.getLogger(__name__)
        logger.error(f"Error exporting per-second sensor data to Excel: {str(e)}")
        messages.error(request, "Error exporting per-second sensor data")
        return redirect('aquaguard:reading-list')


"""================Export Water Usage Data to Excel View function============================="""

@login_required
def export_water_usage_excel(request):
    """Export all water usage data to Excel file (.xlsx)"""
    from datetime import datetime
    
    try:
        # Get all water usage records
        usage_records = WaterUsage.objects.select_related('customer').all().order_by('-usage_date')
        
        # Create workbook
        wb = Workbook()
        ws = wb.active
        ws.title = "Water Usage"
        
        # Write header row
        ws.append([
            'Customer Name',
            'Customer Email',
            'Usage Date',
            'Last 24hr Usage',
            'Monthly Usage',
            'Per Day Average',
            'Current Day Usage'
        ])
        
        # Write water usage rows
        for usage in usage_records:
            ws.append([
                usage.customer.name,
                usage.customer.email,
                usage.usage_date.strftime('%b. %d, %Y') if usage.usage_date else '',
                float(usage.last_24hr_usage) if usage.last_24hr_usage else 0,
                float(usage.monthly_usage) if usage.monthly_usage else 0,
                float(usage.per_day_average) if usage.per_day_average else 0,
                float(usage.current_day_usage) if usage.current_day_usage else 0
            ])
        
        # Prepare response
        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        filename = f"water_usage_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        response['Content-Disposition'] = f'attachment; filename="{filename}"'
        wb.save(response)
        
        messages.success(request, f"Exported {usage_records.count()} water usage records to Excel")
        return response
    
    except Exception as e:
        import logging
        logger = logging.getLogger(__name__)
        logger.error(f"Error exporting water usage to Excel: {str(e)}")
        messages.error(request, "Error exporting water usage data")
        return redirect('aquaguard:dashboard')


# ========== COUPON MANAGEMENT ==========

#================Coupons List View function============================="""

@login_required
def admin_coupons_list(request):
    """List all coupons with filters"""
    coupons = Coupon.objects.all().order_by('-created_at')
    
    # Filters
    status = request.GET.get('status', '')
    coupon_type = request.GET.get('type', '')
    search = request.GET.get('search', '')
    
    if status:
        coupons = coupons.filter(status=status)
    if coupon_type:
        coupons = coupons.filter(coupon_type=coupon_type)
    if search:
        coupons = coupons.filter(coupon_code__icontains=search)
    
    context = {
        'coupons': coupons,
        'status_choices': Coupon.COUPON_STATUS_CHOICES,
        'type_choices': Coupon.COUPON_TYPE_CHOICES,
        'current_status': status,
        'current_type': coupon_type,
        'current_search': search,
        'future_field1': getattr(Coupon, 'future_field1', None),
        'future_field2': getattr(Coupon, 'future_field2', None),
    }
    return render(request, 'aquaguard/admin_coupons_list.html', context)


#================Create Coupon View function============================="""

@login_required
def admin_create_coupon(request):
    """Create new coupon"""
    from datetime import datetime, timedelta, timezone
    from django.http import JsonResponse
    import json
    
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            
            # Validation
            coupon_code = data.get('coupon_code', '').strip().upper()
            if not coupon_code:
                return JsonResponse({'success': False, 'error': 'Coupon code is required'})
            
            # Check if code already exists
            if Coupon.objects.filter(coupon_code=coupon_code).exists():
                return JsonResponse({'success': False, 'error': 'Coupon code already exists'})
            
            coupon_type = data.get('coupon_type', 'percentage')
            if coupon_type not in ['percentage', 'fixed', 'free_litres']:
                return JsonResponse({'success': False, 'error': 'Invalid coupon type'})
            
            discount_value = data.get('discount_value')
            if not discount_value:
                return JsonResponse({'success': False, 'error': 'Discount value is required'})
            
            try:
                discount_value = Decimal(str(discount_value))
                if discount_value <= 0:
                    return JsonResponse({'success': False, 'error': 'Discount value must be greater than 0'})
            except:
                return JsonResponse({'success': False, 'error': 'Invalid discount value'})
            
            valid_from = data.get('valid_from')
            valid_until = data.get('valid_until')
            if not valid_from or not valid_until:
                return JsonResponse({'success': False, 'error': 'Valid dates are required'})
            
            try:
                valid_from = datetime.fromisoformat(valid_from.replace('Z', '+00:00'))
                valid_until = datetime.fromisoformat(valid_until.replace('Z', '+00:00'))
            except:
                return JsonResponse({'success': False, 'error': 'Invalid date format'})
            
            if valid_from >= valid_until:
                return JsonResponse({'success': False, 'error': 'Valid from date must be before valid until date'})
            
            # Create coupon
            coupon = Coupon.objects.create(
                coupon_code=coupon_code,
                coupon_type=coupon_type,
                discount_value=discount_value,
                valid_from=valid_from,
                valid_until=valid_until,
                description=data.get('description', ''),
                max_usage=data.get('max_usage') or None,
                max_usage_per_customer=int(data.get('max_usage_per_customer', 1)),
                min_order_amount=Decimal(str(data.get('min_order_amount', 0))),
                status=data.get('status', 'active') == 'active',
            )
            
            # Add applicable plans if specific plans selected
            apply_to = data.get('apply_to', 'all_plans')
            if apply_to == 'specific_plans':
                plan_ids = data.get('applicable_plans', [])
                if plan_ids:
                    coupon.applicable_plans.set(plan_ids)
            
            return JsonResponse({
                'success': True,
                'message': 'Coupon created successfully',
                'coupon_id': coupon.id
            })
        
        except Exception as e:
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Error creating coupon: {str(e)}")
            return JsonResponse({'success': False, 'error': str(e)})
    
    from datetime import datetime, timedelta, timezone
    plans = SubscriptionPlan.objects.filter(status=True)
    context = {
        'plans': plans,
        'type_choices': Coupon.COUPON_TYPE_CHOICES,
        'status_choices': Coupon.COUPON_STATUS_CHOICES,
        'default_from': datetime.now(timezone.utc).isoformat(),
        'default_until': (datetime.now(timezone.utc) + timedelta(days=30)).isoformat(),
    }
    return render(request, 'aquaguard/admin_create_coupon.html', context)


#================Update Coupon View function============================="""

@login_required
def admin_update_coupon(request, coupon_id):
    """Update existing coupon"""
    from django.http import JsonResponse
    import json
    from decimal import Decimal
    from datetime import datetime
    
    try:
        coupon = Coupon.objects.get(id=coupon_id)
    except Coupon.DoesNotExist:
        if request.method == 'POST':
            return JsonResponse({'success': False, 'error': 'Coupon not found'})
        messages.error(request, 'Coupon not found')
        return redirect('aquaguard:admin-coupons')
    
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            
            # Update basic fields
            coupon.coupon_type = data.get('coupon_type', coupon.coupon_type)
            coupon.description = data.get('description', coupon.description)
            coupon.status = data.get('status', coupon.status) == 'active'
            
            discount_value = data.get('discount_value')
            if discount_value:
                coupon.discount_value = Decimal(str(discount_value))
            
            valid_from = data.get('valid_from')
            valid_until = data.get('valid_until')
            if valid_from:
                coupon.valid_from = datetime.fromisoformat(valid_from.replace('Z', '+00:00'))
            if valid_until:
                coupon.valid_until = datetime.fromisoformat(valid_until.replace('Z', '+00:00'))
            
            coupon.max_usage = data.get('max_usage') or None
            coupon.max_usage_per_customer = int(data.get('max_usage_per_customer', 1))
            coupon.min_order_amount = Decimal(str(data.get('min_order_amount', 0)))
            
            coupon.save()
            
            # Handle applicable plans
            apply_to = data.get('apply_to', 'all_plans')
            if apply_to == 'specific_plans':
                plan_ids = data.get('applicable_plans', [])
                coupon.applicable_plans.set(plan_ids)
            else:
                coupon.applicable_plans.clear()
            
            return JsonResponse({
                'success': True,
                'message': 'Coupon updated successfully'
            })
        
        except Exception as e:
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Error updating coupon: {str(e)}")
            return JsonResponse({'success': False, 'error': str(e)})
    
    plans = SubscriptionPlan.objects.filter(status=True)
    coupon_plan_ids = list(coupon.applicable_plans.values_list('id', flat=True))
    context = {
        'coupon': coupon,
        'plans': plans,
        'coupon_plan_ids': coupon_plan_ids,
        'type_choices': Coupon.COUPON_TYPE_CHOICES,
        'status_choices': Coupon.COUPON_STATUS_CHOICES,
    }
    return render(request, 'aquaguard/admin_update_coupon.html', context)


#================Delete Coupon View function============================="""

@login_required
def admin_delete_coupon(request, coupon_id):
    """Delete coupon"""
    from django.http import JsonResponse
    import json
    
    try:
        coupon = Coupon.objects.get(id=coupon_id)
    except Coupon.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'Coupon not found'})
    
    if request.method == 'POST':
        try:
            coupon_code = coupon.coupon_code
            coupon.delete()
            return JsonResponse({
                'success': True,
                'message': f'Coupon {coupon_code} deleted successfully'
            })
        except Exception as e:
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Error deleting coupon: {str(e)}")
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'})


#================Coupon Detail View function============================="""

@login_required
def admin_coupon_detail(request, coupon_id):
    """View coupon details and usage statistics"""
    try:
        coupon = Coupon.objects.get(id=coupon_id)
    except Coupon.DoesNotExist:
        messages.error(request, 'Coupon not found')
        return redirect('aquaguard:admin-coupons')
    
    from .models import CouponUsage
    
    usages = CouponUsage.objects.filter(coupon=coupon).select_related('customer').order_by('-used_at')
    
    context = {
        'coupon': coupon,
        'usages': usages,
        'usage_count': usages.count(),
        'total_discount': sum(usage.discount_amount for usage in usages),
    }
    return render(request, 'aquaguard/admin_coupon_detail.html', context)


#================Profile Edit Requests Management Views============================="""

@login_required

def admin_edit_requests(request):
    """Admin view to see all profile edit requests"""
    from .models import ProfileEditRequest
    
    status_filter = request.GET.get('status', 'pending')
    if status_filter == 'all':
        edit_requests = ProfileEditRequest.objects.all()
    else:
        edit_requests = ProfileEditRequest.objects.filter(status=status_filter)
    
    context = {
        'edit_requests': edit_requests,
        'status_filter': status_filter,
    }
    return render(request, 'aquaguard/admin_edit_requests.html', context)

@login_required
def admin_process_edit_request(request, request_id):
    """Admin processes a profile edit request"""
    from .models import ProfileEditRequest
    from django.utils import timezone
    
    edit_request = ProfileEditRequest.objects.get(id=request_id)
    
    if request.method == 'POST':
        action = request.POST.get('action')
        
        if action == 'approve':
            edit_request.status = 'approved'
            edit_request.processed_at = timezone.now()
            edit_request.processed_by = request.user.email
            edit_request.admin_notes = request.POST.get('admin_notes', '')
            edit_request.save()
            messages.success(request, f"Edit request for {edit_request.customer.name} approved. You can now edit their profile.")
            return redirect('aquaguard:admin-edit-customer-profile', customer_id=edit_request.customer.id, request_id=request_id)
        
        elif action == 'reject':
            edit_request.status = 'rejected'
            edit_request.processed_at = timezone.now()
            edit_request.processed_by = request.user.email
            edit_request.admin_notes = request.POST.get('admin_notes', '')
            edit_request.save()
            messages.info(request, f"Edit request for {edit_request.customer.name} rejected.")
            return redirect('aquaguard:admin-edit-requests')
    
    context = {
        'edit_request': edit_request,
    }
    return render(request, 'aquaguard/admin_process_edit_request.html', context)


#================Admin Edit Customer Profile View function============================="""

@login_required
def admin_edit_customer_profile(request, customer_id, request_id):
    """Admin edits customer profile after approving request"""
    from .models import ProfileEditRequest
    
    customer = Customer.objects.get(id=customer_id)
    edit_request = None
    if int(request_id) != 0:
        edit_request = ProfileEditRequest.objects.get(id=request_id)

    if request.method == 'POST':
        # Update only allowed fields and keep required ones intact if left blank
        phone_number = request.POST.get('phone_number', '').strip()
        customer.phone_number = phone_number or customer.phone_number

        token_input = request.POST.get('device_token')
        if token_input is None:
            token_input = request.POST.get('token')
        if token_input is not None:
            new_token = token_input.strip()
            if new_token:
                customer.device_token = new_token

        # Keep existing device chip ID unless explicitly provided (request form hides it)
        device_chip_id = request.POST.get('device_chip_id')
        if device_chip_id:
            device_chip_id = device_chip_id.strip()
            if not device_chip_id:
                messages.error(request, "Device chip ID cannot be empty.")
                return redirect(request.path)
            customer.device_chip_id = device_chip_id

        firmware_version_input = request.POST.get('firmware_version')
        if firmware_version_input is None:
            firmware_version_input = request.POST.get('ota_version')
        if firmware_version_input is not None:
            firmware_value = firmware_version_input.strip()
            customer.firmware_version = firmware_value or None
            if hasattr(customer, 'ota_version'):
                customer.ota_version = firmware_value or None

        family_members = request.POST.get('number_of_family_members')
        if family_members:
            try:
                customer.number_of_family_members = int(family_members)
            except ValueError:
                messages.error(request, "Family members must be a number.")
                return redirect(request.path)

        customer.customer_address = request.POST.get('customer_address', customer.customer_address)

        paisa_per_litre = request.POST.get('paisa_per_litre')
        if paisa_per_litre:
            try:
                customer.paisa_per_litre = float(paisa_per_litre)
            except ValueError:
                messages.error(request, "Invalid paisa per litre value.")
                return redirect(request.path)

        board_value = request.POST.get('board')
        if board_value:
            if board_value not in BOARD_OPTION_VALUES:
                messages.error(request, "Invalid board selection.")
                return redirect(request.path)
            customer.board = board_value

        customer_type = request.POST.get('customer_type')
        if customer_type:
            valid_types = dict(Customer.CUSTOMER_TYPE_CHOICES)
            if customer_type not in valid_types:
                messages.error(request, "Invalid customer type selected.")
                return redirect(request.path)
            customer.customer_type = customer_type

        customer.device_token = request.POST.get('device_token', '').strip() or None
        customer.device_health = request.POST.get('device_health', '').strip() or None

        customer.save()
        messages.success(request, f"Profile updated successfully for {customer.name}")
        return redirect('aquaguard:customer-details', customer_id=customer.id)

    context = {
        'customer': customer,
        'edit_request': edit_request,
    }
    return render(request, 'aquaguard/admin_edit_customer_profile.html', context)

#================Sensor Data Ingestion API View function============================="""
@csrf_exempt
@api_view(['POST'])
def ingest_sensor_data(request):
    raw_data = request.data

    # -------- Detect mode --------
    if "data" in raw_data:
        serializer = SensorBatchSerializer(data=raw_data)
        mode = "batch"
    else:
        serializer = SensorDataSerializer(data=raw_data)
        mode = "single"

    if not serializer.is_valid():
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    payload = serializer.validated_data
    device_id = payload["device_id"]
    ts = payload["ts"]
    signature = payload["signature"]

    # -------- Replay protection --------
    if abs(time.time() - ts) > 60:
        return Response({"error": "Request expired"}, status=status.HTTP_403_FORBIDDEN)

    # -------- Get token (cache → DB) --------
    token = get_device_token(device_id)
    if not token:
        return Response({"error": "Invalid device"}, status=status.HTTP_403_FORBIDDEN)

    # -------- Resolve ACTIVE user (CRITICAL FIX) --------
    user = (
        Customer.objects
        .filter(device_chip_id=device_id, is_active=True, block_unblock=True)
        .only("id", "device_token")
        .first()
    )

    if not user:
        return Response({"error": "Invalid device"}, status=status.HTTP_403_FORBIDDEN)

    # -------- Build ORIGINAL payload JSON (for signature) --------
    if mode == "batch":
        original_data_json = json.dumps(
            raw_data["data"],
            separators=(",", ":"),
            ensure_ascii=False,
            sort_keys=False
        )
    else:
        single_data = {
            "water_consumption": raw_data["water_consumption"],
            "tds": raw_data["tds"],
            "ph": raw_data["ph"]
        }
        original_data_json = json.dumps(
            single_data,
            separators=(",", ":"),
            ensure_ascii=False,
            sort_keys=False
        )

    # -------- Verify signature --------
    msg = f"{device_id}{ts}{original_data_json}"
    expected_sig = hmac.new(
        token.encode(),
        msg.encode(),
        hashlib.sha256
    ).hexdigest()

    if not hmac.compare_digest(expected_sig, signature):
        return Response({"error": "Invalid signature"}, status=status.HTTP_403_FORBIDDEN)

    # -------- Update last_seen --------
    Customer.objects.filter(id=user.id).update(last_seen=django_timezone.now())

    # -------- Async save (PASS UID, NOT device_id) --------
    if mode == "batch":
        save_sensor_batch.delay(str(user.id), payload["data"])
    else:
        save_sensor_data.delay(
            str(user.id),
            payload["water_consumption"],
            payload["tds"],
            payload["ph"]
        )

    return Response({"status": "accepted"}, status=status.HTTP_202_ACCEPTED)

#================Daily and Monthly Consumption API View functions============================="""
@api_view(["GET"])
def daily_consumption(request):
    """Get daily water consumption for a customer"""
    serializer = DailyConsumptionSerializer(data=request.query_params)
    serializer.is_valid(raise_exception=True)

    customer_id = serializer.validated_data["uid"]
    date = serializer.validated_data["date"]

    try:
        customer = Customer.objects.get(id=customer_id, is_active=True, block_unblock=True)
    except Customer.DoesNotExist:
        return Response({"error": "Invalid or inactive customer"}, status=status.HTTP_404_NOT_FOUND)

    start = django_timezone.make_aware(datetime.combine(date, datetime.min.time()))
    end = start + timedelta(days=1)

    total = (
        SensorData.objects
        .filter(customer=customer, esp_timestamp__range=(start, end))
        .aggregate(total_liters=Sum("current_volume"))
        .get("total_liters") or 0
    )

    return Response({
        "customer_id": str(customer_id),
        "date": date,
        "daily_consumption_liters": round(float(total), 3)
    })

#================Monthly Consumption API View function============================="""
@api_view(["GET"])
def monthly_consumption(request):
    """Get monthly water consumption for a customer"""
    serializer = MonthlyConsumptionSerializer(data=request.query_params)
    serializer.is_valid(raise_exception=True)

    customer_id = serializer.validated_data["uid"]
    year = serializer.validated_data["year"]
    month = serializer.validated_data["month"]

    try:
        customer = Customer.objects.get(id=customer_id, is_active=True, block_unblock=True)
    except Customer.DoesNotExist:
        return Response({"error": "Invalid or inactive customer"}, status=status.HTTP_404_NOT_FOUND)

    total = (
        SensorData.objects
        .filter(
            customer=customer,
            esp_timestamp__year=year,
            esp_timestamp__month=month
        )
        .aggregate(total_liters=Sum("current_volume"))
        .get("total_liters") or 0
    )

    return Response({
        "customer_id": str(customer_id),
        "year": year,
        "month": month,
        "monthly_consumption_liters": round(float(total), 3)
    })


# ================= OTA API Views =================

import time
from django.core.cache import cache
from .models import Firmware
from .utils import verify_signature, generate_token
from .cache_utils import get_device_token, get_device_meta, clear_device_cache
import secrets


@csrf_exempt
@api_view(['POST'])
def provision_device(request):
    serializer = ProvisionDeviceSerializer(data=request.data)
    if not serializer.is_valid():
        return Response(serializer.errors, status=400)

    device_id = serializer.validated_data["device_id"]

    # SAFE QUERY - Use Customer model instead of UserInfo
    customer = Customer.objects.filter(
        device_chip_id=device_id,
        is_active=True,
        block_unblock=True
    ).first()

    if not customer:
        return Response(
            {"error": "No active customer assigned to this device"},
            status=404
        )

    if customer.device_token:
        return Response(
            {"error": "Device already provisioned"},
            status=403
        )

    customer.device_token = generate_token()
    customer.save(update_fields=["device_token"])

    # cache by device_chip_id (IMPORTANT)
    cache.set(f"token:{device_id}", customer.device_token, 3600)

    return Response(
        {"token": customer.device_token},
        status=200
    )


@api_view(['GET'])
def check_ota(request):
    serializer = CheckOTASerializer(data=request.query_params)
    if not serializer.is_valid():
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    data = serializer.validated_data
    device_id = data['device_id']
    version = data['version']
    ts = data['ts']  # Now an integer from serializer validation
    signature = data['signature']

    # Replay protection (±60s)
    if abs(time.time() - ts) > 60:
        return Response(
            {"error": "Request expired"},
            status=status.HTTP_403_FORBIDDEN
        )

    # TOKEN (Redis → DB fallback)
    token = get_device_token(device_id)
    if not token:
        return Response(
            {"error": "Invalid device"},
            status=status.HTTP_403_FORBIDDEN
        )

    # Signature verification
    if not verify_signature(device_id, version, ts, signature, token):
        return Response(
            {"error": "Invalid signature"},
            status=status.HTTP_403_FORBIDDEN
        )

    # DEVICE META (Redis → DB fallback)
    meta = get_device_meta(device_id)
    if not meta:
        return Response({"update": False})

    target_version = meta["firmware_version"]
    board = meta["board"]

    # OTA decision
    if version != target_version:
        fw = Firmware.objects.filter(
            board=board,
            version=target_version,
            is_active=True
        ).only("version", "bin_file").first()

        if not fw:
            return Response({"update": False})

        return Response({
            "update": True,
            "version": fw.version,
            "url": fw.bin_file.url
        })

    return Response({"update": False})


# Android App APIs
"""================Customer Registration and Login API View functions============================="""
@api_view(['POST'])
@csrf_exempt
def customer_registration(request):
    """
    Customer registration API for Android app
    POST: Register new customer
    """
    serializer = CustomerRegistrationSerializer(data=request.data)
    
    if serializer.is_valid():
        try:
            customer = serializer.save()
            return Response({
                "success": True,
                "message": "Customer registered successfully",
                "data": {
                    "customer_id": str(customer.id),
                    "device_token": customer.device_token,
                    "email_verified": customer.email_verified
                }
            }, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({
                "success": False,
                "message": f"Registration failed: {str(e)}"
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    return Response({
        "success": False,
        "message": "Validation failed",
        "errors": serializer.errors
    }, status=status.HTTP_400_BAD_REQUEST)


"""================Customer Registration and Login API View functions============================="""

@api_view(['POST'])
@csrf_exempt
def customer_login(request):
    """
    Customer login API for Android app
    POST: Authenticate customer with email and password
    """
    serializer = CustomerLoginSerializer(data=request.data)
    
    if not serializer.is_valid():
        return Response({
            "success": False,
            "message": "Invalid input data",
            "errors": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)
    
    email = serializer.validated_data['email']
    password = serializer.validated_data['password']
    
    try:
        # Check if customer exists
        customer = Customer.objects.get(email=email)
        
        # Check password
        from django.contrib.auth.hashers import check_password
        if not check_password(password, customer.password):
            return Response({
                "success": False,
                "message": "Password does not match"
            }, status=status.HTTP_401_UNAUTHORIZED)
        
        # Check if customer is active/blocked
        if not customer.block_unblock:
            return Response({
                "success": False,
                "message": "Account is blocked. Please contact support."
            }, status=status.HTTP_403_FORBIDDEN)
        
        # Successful login - return customer profile
        profile_serializer = CustomerProfileSerializer(customer)
        return Response({
            "success": True,
            "message": "Login successful",
            "data": profile_serializer.data
        }, status=status.HTTP_200_OK)
        
    except Customer.DoesNotExist:
        return Response({
            "success": False,
            "message": "Email does not exist"
        }, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({
            "success": False,
            "message": f"Login failed: {str(e)}"
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#================Customer Info API View function============================="""
@api_view(['GET'])
@csrf_exempt
def customer_info(request, customer_id):
    """
    Customer info API for Android app
    GET: Get customer information by UUID
    """
    try:
        # Validate UUID format
        from uuid import UUID
        try:
            customer_uuid = UUID(customer_id)
        except ValueError:
            return Response({
                "success": False,
                "message": "Invalid customer ID format"
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Get customer by UUID
        customer = Customer.objects.get(id=customer_uuid)
        
        # Check if customer is active/blocked
        if not customer.block_unblock:
            return Response({
                "success": False,
                "message": "Account is blocked. Please contact support."
            }, status=status.HTTP_403_FORBIDDEN)
        
        # Return customer info
        info_serializer = CustomerInfoSerializer(customer)
        return Response({
            "success": True,
            "message": "Customer info retrieved successfully",
            "data": info_serializer.data
        }, status=status.HTTP_200_OK)
        
    except Customer.DoesNotExist:
        return Response({
            "success": False,
            "message": "Customer not found"
        }, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({
            "success": False,
            "message": f"Failed to retrieve customer info: {str(e)}"
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#================Customer Location Update API View function============================="""
@api_view(['POST'])
@csrf_exempt
def customer_location(request, customer_id):
    """
    Customer location update API for Android app
    POST: Update customer location data by UUID
    """
    try:
        # Validate UUID format
        from uuid import UUID
        try:
            customer_uuid = UUID(customer_id)
        except ValueError:
            return Response({
                "success": False,
                "message": "Invalid customer ID format"
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Get customer by UUID
        customer = Customer.objects.get(id=customer_uuid)
        
        # Check if customer is active/blocked
        if not customer.block_unblock:
            return Response({
                "success": False,
                "message": "Account is blocked. Please contact support."
            }, status=status.HTTP_403_FORBIDDEN)
        
        # Validate location data
        serializer = CustomerLocationSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                "success": False,
                "message": "Invalid location data",
                "errors": serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Update customer location
        customer.latitude = serializer.validated_data['latitude']
        customer.longitude = serializer.validated_data['longitude']
        customer.location = serializer.validated_data['location']
        customer.save(update_fields=['latitude', 'longitude', 'location'])
        
        return Response({
            "success": True,
            "message": "Location updated successfully",
            "data": {
                "latitude": customer.latitude,
                "longitude": customer.longitude,
                "location": customer.location
            }
        }, status=status.HTTP_200_OK)
        
    except Customer.DoesNotExist:
        return Response({
            "success": False,
            "message": "Customer not found"
        }, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({
            "success": False,
            "message": f"Failed to update location: {str(e)}"
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#================Customer Water Usage API View function============================="""

@api_view(['GET'])
@csrf_exempt
def customer_water_usage(request, customer_id):
    """
    Customer water usage API for Android app
    GET: Get water usage statistics by customer UUID
    """
    try:
        # Validate UUID format
        from uuid import UUID
        try:
            customer_uuid = UUID(customer_id)
        except ValueError:
            return Response({
                "success": False,
                "message": "Invalid customer ID format"
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Get customer by UUID
        customer = Customer.objects.get(id=customer_uuid)
        
        # Check if customer is active/blocked
        if not customer.block_unblock:
            return Response({
                "success": False,
                "message": "Account is blocked. Please contact support."
            }, status=status.HTTP_403_FORBIDDEN)
        
        # Get the latest water usage record for this customer
        try:
            latest_usage = WaterUsage.objects.filter(customer=customer).latest('usage_date')
            
            # Serialize the data
            serializer = CustomerWaterUsageSerializer(latest_usage)
            return Response({
                "success": True,
                "message": "Water usage data retrieved successfully",
                "data": serializer.data
            }, status=status.HTTP_200_OK)
            
        except WaterUsage.DoesNotExist:
            # If no usage data exists, return zeros
            return Response({
                "success": True,
                "message": "No water usage data available",
                "data": {
                    "customer": customer.name,
                    "last_24_usage": 0.0,
                    "monthly_usage": 0.0,
                    "per_day_average": 0.0,
                    "current_day_usage": 0.0
                }
            }, status=status.HTTP_200_OK)
        
    except Customer.DoesNotExist:
        return Response({
            "success": False,
            "message": "Customer not found"
        }, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({
            "success": False,
            "message": f"Failed to retrieve water usage data: {str(e)}"
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#================Customer Recharge Info API View function============================="""
@api_view(['GET'])
@csrf_exempt
def customer_recharge_info(request, customer_id):
    """
    Customer recharge info API for Android app
    GET: Get recharge information by customer UUID
    """
    try:
        # Validate UUID format
        from uuid import UUID
        try:
            customer_uuid = UUID(customer_id)
        except ValueError:
            return Response({
                "success": False,
                "message": "Invalid customer ID format"
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Get customer by UUID
        customer = Customer.objects.get(id=customer_uuid)
        
        # Check if customer is active/blocked
        if not customer.block_unblock:
            return Response({
                "success": False,
                "message": "Account is blocked. Please contact support."
            }, status=status.HTTP_403_FORBIDDEN)
        
        # Get the latest/active recharge record for this customer
        try:
            # First try to get active recharge, if none, get the latest one
            recharge = Recharge.objects.filter(
                customer=customer, 
                status='active'
            ).first()
            
            if not recharge:
                # If no active recharge, get the latest one
                recharge = Recharge.objects.filter(customer=customer).latest('recharge_date')
            
            # Serialize the data
            serializer = CustomerRechargeInfoSerializer(recharge)
            return Response({
                "success": True,
                "message": "Recharge info retrieved successfully",
                "data": serializer.data
            }, status=status.HTTP_200_OK)
            
        except Recharge.DoesNotExist:
            # If no recharge data exists
            return Response({
                "success": False,
                "message": "No recharge information available"
            }, status=status.HTTP_404_NOT_FOUND)
        
    except Customer.DoesNotExist:
        return Response({
            "success": False,
            "message": "Customer not found"
        }, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({
            "success": False,
            "message": f"Failed to retrieve recharge info: {str(e)}"
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#================Customer Payment Details API View function============================="""
@api_view(['POST'])
@csrf_exempt
def customer_payment_details(request, customer_id):
    """
    Customer payment details API for Android app
    POST: Store payment information by customer UUID
    """
    try:
        # Validate UUID format
        from uuid import UUID
        try:
            customer_uuid = UUID(customer_id)
        except ValueError:
            return Response({
                "success": False,
                "message": "Invalid customer ID format"
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Get customer by UUID
        customer = Customer.objects.get(id=customer_uuid)
        
        # Check if customer is active/blocked
        if not customer.block_unblock:
            return Response({
                "success": False,
                "message": "Account is blocked. Please contact support."
            }, status=status.HTTP_403_FORBIDDEN)
        
        # Validate payment data
        serializer = PaymentCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                "success": False,
                "message": "Invalid payment data",
                "errors": serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Check if order_id already exists
        order_id = serializer.validated_data['order_id']
        if Payment.objects.filter(order_id=order_id).exists():
            return Response({
                "success": False,
                "message": "Order ID already exists"
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Create payment record
        payment = Payment.objects.create(
            customer=customer,
            amount=serializer.validated_data['amount'],
            order_id=order_id,
            payment_status=serializer.validated_data['payment_status'],
            transaction_id=serializer.validated_data.get('transaction_id', ''),
        )
        
        # If recharge_date is provided, update it
        if 'recharge_date' in serializer.validated_data:
            payment.recharge_date = serializer.validated_data['recharge_date']
            payment.save()
        
        return Response({
            "success": True,
            "message": "Payment details stored successfully",
            "data": {
                "payment_id": payment.id,
                "customer": customer.name,
                "email": customer.email,
                "amount": str(payment.amount),
                "recharge_date": payment.recharge_date.isoformat(),
                "order_id": payment.order_id,
                "payment_status": payment.payment_status,
                "transaction_id": payment.transaction_id
            }
        }, status=status.HTTP_201_CREATED)
        
    except Customer.DoesNotExist:
        return Response({
            "success": False,
            "message": "Customer not found"
        }, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({
            "success": False,
            "message": f"Failed to store payment details: {str(e)}"
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#================Subscription Info API View function============================="""
@api_view(['GET'])
@csrf_exempt
def subscription_info(request):
    """
    Subscription info API for Android app
    GET: Get all available subscription plans (public API, no authentication required)
    """
    try:
        # Get all active subscription plans
        subscription_plans = SubscriptionPlan.objects.filter(status=True)
        
        # Serialize the data
        serializer = SubscriptionInfoSerializer(subscription_plans, many=True)
        
        return Response({
            "success": True,
            "message": "Subscription plans retrieved successfully",
            "data": serializer.data
        }, status=status.HTTP_200_OK)
        
    except Exception as e:
        return Response({
            "success": False,
            "message": f"Failed to retrieve subscription plans: {str(e)}"
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#================Customer Complaint API View function============================="""
@api_view(['GET', 'POST'])
@csrf_exempt
def customer_complaint(request, customer_id):
    """
    Customer complaint API for Android app
    GET: Retrieve customer complaints by UUID
    POST: Create customer complaint by UUID
    """
    try:
        # Validate UUID format
        from uuid import UUID
        try:
            customer_uuid = UUID(customer_id)
        except ValueError:
            return Response({
                "success": False,
                "message": "Invalid customer ID format"
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Get customer by UUID
        customer = Customer.objects.get(id=customer_uuid)
        
        # Check if customer is active/blocked
        if not customer.block_unblock:
            return Response({
                "success": False,
                "message": "Account is blocked. Please contact support."
            }, status=status.HTTP_403_FORBIDDEN)
        
        if request.method == 'GET':
            # Retrieve customer's complaints
            complaints = UserComplain.objects.filter(customer=customer).order_by('-complain_date')
            serializer = UserComplainCustomerSerializer(complaints, many=True)
            return Response({
                "success": True,
                "message": "Complaints retrieved successfully",
                "data": serializer.data
            }, status=status.HTTP_200_OK)
        
        elif request.method == 'POST':
            # Validate complaint data
            serializer = UserComplainCreateSerializer(data=request.data)
            if not serializer.is_valid():
                return Response({
                    "success": False,
                    "message": "Invalid complaint data",
                    "errors": serializer.errors
                }, status=status.HTTP_400_BAD_REQUEST)
            
            # Generate unique ticket number
            import random
            import string
            ticket_number = f"TKT-{customer.id.hex[:8].upper()}-{random.randint(1000, 9999)}"
            
            # Ensure ticket number is unique
            while UserComplain.objects.filter(ticket_number=ticket_number).exists():
                ticket_number = f"TKT-{customer.id.hex[:8].upper()}-{random.randint(1000, 9999)}"
            
            # Create complaint
            complaint = UserComplain.objects.create(
                customer=customer,
                phone_no=serializer.validated_data['phone_no'],
                problem_statement=serializer.validated_data['problem_statement'],
                priority=serializer.validated_data.get('priority', 'medium'),
                ticket_number=ticket_number,
                future_field1=customer.email,  # Store email in future_field1
            )
            
            return Response({
                "success": True,
                "message": "Complaint submitted successfully",
                "data": {
                    "complaint_id": complaint.id,
                    "customer": customer.name,
                    "phone_no": complaint.phone_no,
                    "email": customer.email,
                    "ticket_number": complaint.ticket_number,
                    "problem_statement": complaint.problem_statement,
                    "complain_date": complaint.complain_date.isoformat(),
                    "priority": complaint.priority,
                    "status": complaint.status
                }
            }, status=status.HTTP_201_CREATED)
        
        else:
            return Response({
                "success": False,
                "message": "Method not allowed"
            }, status=status.HTTP_405_METHOD_NOT_ALLOWED)
        
    except Customer.DoesNotExist:
        return Response({
            "success": False,
            "message": "Customer not found"
        }, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({
            "success": False,
            "message": f"Failed to process request: {str(e)}"
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# ========== ESP DEVICE APIs health status post==========
@api_view(['POST'])
@csrf_exempt
def esp_device_health(request):
    """
    ESP Device Health Status API
    POST: ESP device reports its health status
    Verifies device_id, ts, signature, token, then updates device health in DB
    """
    try:
        # Validate request data
        serializer = ESPDeviceHealthSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                "success": False,
                "message": "Invalid request data",
                "errors": serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        device_id = serializer.validated_data['device_id']
        ts = serializer.validated_data['ts']
        signature = serializer.validated_data['signature']
        token = serializer.validated_data['token']
        health_status = serializer.validated_data['health_status']

        # Verify signature: device_id + ts + health_status signed with token
        ts_str = str(int(ts))
        msg = f"{device_id}{ts_str}{health_status}".encode()
        expected_sig = hmac.new(
            token.encode(),
            msg,
            hashlib.sha256
        ).hexdigest()

        if not hmac.compare_digest(expected_sig, signature):
            return Response({
                "success": False,
                "message": "Invalid signature"
            }, status=status.HTTP_403_FORBIDDEN)

        # Get customer by device_id and verify token matches
        try:
            customer = Customer.objects.get(
                device_chip_id=device_id,
                device_token=token,
                is_active=True
            )
        except Customer.DoesNotExist:
            return Response({
                "success": False,
                "message": "Device not found or invalid token"
            }, status=status.HTTP_404_NOT_FOUND)

        # Update device health status and last_seen timestamp
        Customer.objects.filter(id=customer.id).update(
            device_health=health_status,
            last_seen=django_timezone.now()
        )

        # Return success response
        return Response({
            "success": True,
            "device_id": device_id,
            "health_status": health_status,
            "timestamp": int(time.time()),
            "message": "Device health status updated successfully"
        }, status=status.HTTP_200_OK)

    except Exception as e:
        return Response({
            "success": False,
            "message": f"Failed to update device health: {str(e)}"
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# ========== ESP DEVICE APIs calibration factor get==========
@api_view(['GET'])
@csrf_exempt
def esp_calibration_factor(request):
    """
    ESP Device Calibration Factor API
    GET: ESP device requests its calibration factor
    Verifies device_id, ts, signature, token, then returns calibration factor
    """
    try:
        # Validate request data
        serializer = ESPCalibrationFactorSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                "success": False,
                "message": "Invalid request data",
                "errors": serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        device_id = serializer.validated_data['device_id']
        ts = serializer.validated_data['ts']
        signature = serializer.validated_data['signature']
        token = serializer.validated_data['token']

        # Verify signature: device_id + ts signed with token
        ts_str = str(int(ts))
        msg = f"{device_id}{ts_str}".encode()
        expected_sig = hmac.new(
            token.encode(),
            msg,
            hashlib.sha256
        ).hexdigest()

        if not hmac.compare_digest(expected_sig, signature):
            return Response({
                "success": False,
                "message": "Invalid signature"
            }, status=status.HTTP_403_FORBIDDEN)

        # Get customer by device_id and verify token matches
        try:
            customer = Customer.objects.get(
                device_chip_id=device_id,
                device_token=token,
                is_active=True
            )
        except Customer.DoesNotExist:
            return Response({
                "success": False,
                "message": "Device not found or invalid token"
            }, status=status.HTTP_404_NOT_FOUND)

        # Get the latest calibration factor for this customer
        try:
            latest_calibration = CalibrationData.objects.filter(
                customer=customer
            ).order_by('-recorded_at').first()

            if latest_calibration:
                calibration_factor = latest_calibration.calibration_factor
                recorded_at = latest_calibration.recorded_at.isoformat()
            else:
                # No calibration data found, return default
                calibration_factor = 1.0  # Default calibration factor
                recorded_at = None

        except Exception as e:
            # If there's an error getting calibration data, return default
            calibration_factor = 1.0
            recorded_at = None

        # Update last_seen timestamp
        Customer.objects.filter(id=customer.id).update(last_seen=django_timezone.now())

        # Return calibration factor response
        return Response({
            "success": True,
            "device_id": device_id,
            "calibration_factor": calibration_factor,
            "recorded_at": recorded_at,
            "timestamp": int(time.time()),
            "message": "Calibration factor retrieved successfully"
        }, status=status.HTTP_200_OK)

    except Exception as e:
        return Response({
            "success": False,
            "message": f"Failed to retrieve calibration factor: {str(e)}"
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['POST'])
@csrf_exempt
def fcm_token_register(request):
    """
    FCM Token Registration API
    POST: Mobile app registers/updates FCM token for push notifications
    """
    try:
        # Validate request data
        serializer = FCMTokenSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                "success": False,
                "message": "Invalid request data",
                "errors": serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        customer_id = serializer.validated_data['customer_id']
        fcm_token = serializer.validated_data['fcm_token']

        # Get customer by UUID
        try:
            customer = Customer.objects.get(id=customer_id, is_active=True)
        except Customer.DoesNotExist:
            return Response({
                "success": False,
                "message": "Customer not found"
            }, status=status.HTTP_404_NOT_FOUND)

        # Update FCM token
        Customer.objects.filter(id=customer.id).update(
            fcm_token=fcm_token,
            updated_at=django_timezone.now()
        )

        # Return success response
        return Response({
            "success": True,
            "customer_id": str(customer_id),
            "message": "FCM token registered successfully"
        }, status=status.HTTP_200_OK)

    except Exception as e:
        return Response({
            "success": False,
            "message": f"Failed to register FCM token: {str(e)}"
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# ========== ESP DEVICE APIs sensor data post==========
@api_view(['POST'])
@csrf_exempt
def esp_sensor_data(request):
    """
    ESP Device Sensor Data API
    POST: ESP device submits sensor data for storage
    Verifies device_id, ts, signature, token & JSON data, then inserts to DB
    """
    try:
        # Validate request data
        serializer = ESPSensorDataSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                "success": False,
                "message": "Invalid request data",
                "errors": serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        device_id = serializer.validated_data['device_id']
        ts = serializer.validated_data['ts']
        signature = serializer.validated_data['signature']
        token = serializer.validated_data['token']
        sensor_data = serializer.validated_data['data']

        # Verify signature: device_id + ts + JSON data signed with token
        # Create the JSON string exactly as the ESP would send it
        data_json = json.dumps(
            sensor_data,
            separators=(",", ":"),
            sort_keys=False,
            ensure_ascii=False
        )
        ts_str = str(int(ts))
        msg = f"{device_id}{ts_str}{data_json}".encode()

        expected_sig = hmac.new(
            token.encode(),
            msg,
            hashlib.sha256
        ).hexdigest()

        if not hmac.compare_digest(expected_sig, signature):
            return Response({
                "success": False,
                "message": "Invalid signature"
            }, status=status.HTTP_403_FORBIDDEN)

        # Get customer by device_id and verify token matches
        try:
            customer = Customer.objects.get(
                device_chip_id=device_id,
                device_token=token,
                is_active=True,
                block_unblock=True  # Only allow active/unblocked devices to submit data
            )
        except Customer.DoesNotExist:
            return Response({
                "success": False,
                "message": "Device not found, invalid token, or device is blocked"
            }, status=status.HTTP_404_NOT_FOUND)

        # Update last_seen timestamp
        Customer.objects.filter(id=customer.id).update(last_seen=django_timezone.now())

        # Async save sensor data (PASS customer ID, NOT device_id)
        save_sensor_batch.delay(str(customer.id), sensor_data)

        # Return success response
        return Response({
            "success": True,
            "device_id": device_id,
            "data_points": len(sensor_data),
            "timestamp": int(time.time()),
            "message": "Sensor data accepted for processing"
        }, status=status.HTTP_202_ACCEPTED)

    except Exception as e:
        return Response({
            "success": False,
            "message": f"Failed to process sensor data: {str(e)}"
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# ========== ESP DEVICE APIs ota check ==========
@api_view(['GET'])
@csrf_exempt
def esp_ota_status_check(request):
    """
    ESP Device OTA Status Check API
    GET: ESP device requests OTA status information
    Verifies device_id, ts, signature & token
    """
    try:
        # Validate request data
        serializer = ESPOTAStatusCheckSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                "success": False,
                "message": "Invalid request data",
                "errors": serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        device_id = serializer.validated_data['device_id']
        ts = serializer.validated_data['ts']
        signature = serializer.validated_data['signature']
        token = serializer.validated_data['token']

        # Verify signature: device_id + ts signed with token
        ts_str = str(int(ts))
        msg = f"{device_id}{ts_str}".encode()
        expected_sig = hmac.new(
            token.encode(),
            msg,
            hashlib.sha256
        ).hexdigest()

        if not hmac.compare_digest(expected_sig, signature):
            return Response({
                "success": False,
                "message": "Invalid signature"
            }, status=status.HTTP_403_FORBIDDEN)

        # Get customer by device_id and verify token matches
        try:
            customer = Customer.objects.get(
                device_chip_id=device_id,
                device_token=token,
                is_active=True
            )
        except Customer.DoesNotExist:
            return Response({
                "success": False,
                "message": "Device not found or invalid token"
            }, status=status.HTTP_404_NOT_FOUND)

        # Check if device is blocked - blocked devices shouldn't get OTA updates
        if not customer.block_unblock:
            return Response({
                "success": False,
                "message": "Device is blocked",
                "ota_available": False
            }, status=status.HTTP_403_FORBIDDEN)

        # Return OTA status information
        # For now, return basic status - can be extended with actual firmware version checking
        return Response({
            "success": True,
            "device_id": device_id,
            "ota_available": True,  # Placeholder - would check against current firmware version
            "current_version": customer.device_firmware_version or "unknown",
            "board_type": customer.device_board or "unknown",
            "last_check": int(time.time()),
            "message": "OTA status check successful"
        }, status=status.HTTP_200_OK)

    except Exception as e:
        return Response({
            "success": False,
            "message": f"Failed to process OTA status check: {str(e)}"
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# ========== ESP DEVICE APIs block unblock ==========

@api_view(['GET'])
@csrf_exempt
def esp_block_unblock_status(request):
    """
    ESP Device Block/Unblock Status API
    GET: ESP device requests its block/unblock status
    Verifies device_id, ts, signature & token
    """
    try:
        # Validate request data
        serializer = ESPBlockUnblockStatusSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({
                "success": False,
                "message": "Invalid request data",
                "errors": serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)

        device_id = serializer.validated_data['device_id']
        ts = serializer.validated_data['ts']
        signature = serializer.validated_data['signature']
        token = serializer.validated_data['token']

        # Verify signature: device_id + ts signed with token
        ts_str = str(int(ts))
        msg = f"{device_id}{ts_str}".encode()
        expected_sig = hmac.new(
            token.encode(),
            msg,
            hashlib.sha256
        ).hexdigest()

        if not hmac.compare_digest(expected_sig, signature):
            return Response({
                "success": False,
                "message": "Invalid signature"
            }, status=status.HTTP_403_FORBIDDEN)

        # Get customer by device_id and verify token matches
        try:
            customer = Customer.objects.get(
                device_chip_id=device_id,
                device_token=token,
                is_active=True
            )
        except Customer.DoesNotExist:
            return Response({
                "success": False,
                "message": "Device not found or invalid token"
            }, status=status.HTTP_404_NOT_FOUND)

        # Return block/unblock status
        return Response({
            "success": True,
            "device_id": device_id,
            "block_unblock": customer.block_unblock,  # True=Active/Unblocked, False=Blocked/Inactive
            "timestamp": int(time.time())
        }, status=status.HTTP_200_OK)

    except Exception as e:
        return Response({
            "success": False,
            "message": f"Failed to process request: {str(e)}"
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
