import json
import hmac
import hashlib
import time
from django.test import TestCase
from django.urls import reverse
from rest_framework.test import APITestCase
from rest_framework import status
from .models import Customer, SensorData, CalibrationData
from django.utils import timezone


class ESPAPITestCase(APITestCase):
    """Test cases for ESP Device APIs"""

    def setUp(self):
        """Set up test data"""
        # Create test customer with ESP device
        self.customer = Customer.objects.create(
            name="Test Customer",
            email="test@example.com",
            phone="1234567890",
            device_chip_id="ESP32_TEST_DEVICE_001",
            device_token="test_device_token_123",
            device_firmware_version="1.0.0",
            device_board="esp32",
            is_active=True,
            block_unblock=True,
            device_health="OK"
        )

        # Create another blocked customer for testing
        self.blocked_customer = Customer.objects.create(
            name="Blocked Customer",
            email="blocked@example.com",
            phone="0987654321",
            device_chip_id="ESP32_BLOCKED_DEVICE_001",
            device_token="blocked_device_token_123",
            is_active=True,
            block_unblock=False,  # Blocked
            device_health="OK"
        )

        # Create calibration data
        CalibrationData.objects.create(
            customer=self.customer,
            calibration_factor=1.234,
            recorded_at=timezone.now()
        )

    def generate_signature(self, device_id, timestamp, token, additional_data=""):
        """Generate HMAC-SHA256 signature as ESP would"""
        ts_str = str(int(timestamp))
        msg = f"{device_id}{ts_str}{additional_data}".encode()
        return hmac.new(
            token.encode(),
            msg,
            hashlib.sha256
        ).hexdigest()

    def test_esp_block_unblock_status_success(self):
        """Test successful block/unblock status request"""
        ts = int(time.time())
        signature = self.generate_signature(
            self.customer.device_chip_id,
            ts,
            self.customer.device_token
        )

        data = {
            "device_id": self.customer.device_chip_id,
            "ts": ts,
            "signature": signature,
            "token": self.customer.device_token
        }

        response = self.client.post(reverse('esp-block-unblock-status'), data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(response.data['success'])
        self.assertEqual(response.data['device_id'], self.customer.device_chip_id)
        self.assertEqual(response.data['block_unblock'], self.customer.block_unblock)

    def test_esp_block_unblock_status_invalid_signature(self):
        """Test block/unblock status with invalid signature"""
        ts = int(time.time())
        data = {
            "device_id": self.customer.device_chip_id,
            "ts": ts,
            "signature": "invalid_signature",
            "token": self.customer.device_token
        }

        response = self.client.post(reverse('esp-block-unblock-status'), data, format='json')
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        self.assertFalse(response.data['success'])
        self.assertEqual(response.data['message'], "Invalid signature")

    def test_esp_block_unblock_status_device_not_found(self):
        """Test block/unblock status with non-existent device"""
        ts = int(time.time())
        signature = self.generate_signature("NON_EXISTENT_DEVICE", ts, "fake_token")

        data = {
            "device_id": "NON_EXISTENT_DEVICE",
            "ts": ts,
            "signature": signature,
            "token": "fake_token"
        }

        response = self.client.post(reverse('esp-block-unblock-status'), data, format='json')
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
        self.assertFalse(response.data['success'])
        self.assertEqual(response.data['message'], "Device not found or invalid token")

    def test_esp_ota_status_check_success(self):
        """Test successful OTA status check"""
        ts = int(time.time())
        signature = self.generate_signature(
            self.customer.device_chip_id,
            ts,
            self.customer.device_token
        )

        data = {
            "device_id": self.customer.device_chip_id,
            "ts": ts,
            "signature": signature,
            "token": self.customer.device_token
        }

        response = self.client.get(reverse('esp-ota-status-check'), data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(response.data['success'])
        self.assertTrue(response.data['ota_available'])
        self.assertEqual(response.data['current_version'], self.customer.device_firmware_version)

    def test_esp_ota_status_check_blocked_device(self):
        """Test OTA status check for blocked device"""
        ts = int(time.time())
        signature = self.generate_signature(
            self.blocked_customer.device_chip_id,
            ts,
            self.blocked_customer.device_token
        )

        data = {
            "device_id": self.blocked_customer.device_chip_id,
            "ts": ts,
            "signature": signature,
            "token": self.blocked_customer.device_token
        }

        response = self.client.get(reverse('esp-ota-status-check'), data, format='json')
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        self.assertFalse(response.data['success'])
        self.assertEqual(response.data['message'], "Device is blocked")
        self.assertFalse(response.data['ota_available'])

    def test_esp_sensor_data_success(self):
        """Test successful sensor data submission"""
        ts = int(time.time())
        sensor_data = [
            {
                "esp_timestamp": ts,
                "total_volume": "100.5",
                "current_volume": "50.2",
                "water_quality": "Good",
                "tds": "150",
                "ph": "7.2",
                "system_health": "OK"
            }
        ]

        # Generate signature with JSON data
        data_json = json.dumps(sensor_data, separators=(",", ":"), sort_keys=False, ensure_ascii=False)
        signature = self.generate_signature(
            self.customer.device_chip_id,
            ts,
            self.customer.device_token,
            data_json
        )

        data = {
            "device_id": self.customer.device_chip_id,
            "ts": ts,
            "signature": signature,
            "token": self.customer.device_token,
            "data": sensor_data
        }

        response = self.client.post(reverse('esp-sensor-data'), data, format='json')
        self.assertEqual(response.status_code, status.HTTP_202_ACCEPTED)
        self.assertTrue(response.data['success'])
        self.assertEqual(response.data['data_points'], len(sensor_data))

    def test_esp_sensor_data_invalid_signature(self):
        """Test sensor data submission with invalid signature"""
        ts = int(time.time())
        sensor_data = [
            {
                "esp_timestamp": ts,
                "total_volume": "100.5",
                "current_volume": "50.2",
                "water_quality": "Good",
                "tds": "150",
                "ph": "7.2",
                "system_health": "OK"
            }
        ]

        data = {
            "device_id": self.customer.device_chip_id,
            "ts": ts,
            "signature": "invalid_signature",
            "token": self.customer.device_token,
            "data": sensor_data
        }

        response = self.client.post(reverse('esp-sensor-data'), data, format='json')
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        self.assertFalse(response.data['success'])
        self.assertEqual(response.data['message'], "Invalid signature")

    def test_esp_device_health_success(self):
        """Test successful device health update"""
        ts = int(time.time())
        health_status = "OK"

        signature = self.generate_signature(
            self.customer.device_chip_id,
            ts,
            self.customer.device_token,
            health_status
        )

        data = {
            "device_id": self.customer.device_chip_id,
            "ts": ts,
            "signature": signature,
            "token": self.customer.device_token,
            "health_status": health_status
        }

        response = self.client.post(reverse('esp-device-health'), data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(response.data['success'])
        self.assertEqual(response.data['health_status'], health_status)

        # Verify database was updated
        self.customer.refresh_from_db()
        self.assertEqual(self.customer.device_health, health_status)

    def test_esp_calibration_factor_success(self):
        """Test successful calibration factor retrieval"""
        ts = int(time.time())
        signature = self.generate_signature(
            self.customer.device_chip_id,
            ts,
            self.customer.device_token
        )

        data = {
            "device_id": self.customer.device_chip_id,
            "ts": ts,
            "signature": signature,
            "token": self.customer.device_token
        }

        response = self.client.post(reverse('esp-calibration-factor'), data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(response.data['success'])
        self.assertEqual(response.data['calibration_factor'], 1.234)

    def test_esp_calibration_factor_no_data(self):
        """Test calibration factor retrieval when no calibration data exists"""
        # Create customer without calibration data
        customer_no_cal = Customer.objects.create(
            name="No Cal Customer",
            email="nocal@example.com",
            phone="1111111111",
            device_chip_id="ESP32_NO_CAL_DEVICE_001",
            device_token="no_cal_device_token_123",
            is_active=True,
            block_unblock=True
        )

        ts = int(time.time())
        signature = self.generate_signature(
            customer_no_cal.device_chip_id,
            ts,
            customer_no_cal.device_token
        )

        data = {
            "device_id": customer_no_cal.device_chip_id,
            "ts": ts,
            "signature": signature,
            "token": customer_no_cal.device_token
        }

        response = self.client.post(reverse('esp-calibration-factor'), data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(response.data['success'])
        self.assertEqual(response.data['calibration_factor'], 1.0)  # Default value
        self.assertIsNone(response.data['recorded_at'])
