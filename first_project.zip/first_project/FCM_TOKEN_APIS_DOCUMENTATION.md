# FCM Token APIs Documentation

This document provides comprehensive details for FCM (Firebase Cloud Messaging) token management APIs in the Water Rental System.

## Table of Contents
- [Overview](#overview)
- [FCM Token Registration API](#fcm-token-registration-api)
- [Postman Collection](#postman-collection)
- [Testing Scenarios](#testing-scenarios)
- [Integration Guide](#integration-guide)

## Overview

Firebase Cloud Messaging (FCM) enables push notifications to be sent to mobile applications. The Water Rental System uses FCM to send notifications about:

- Water usage alerts
- Payment reminders
- Device status updates
- Maintenance notifications
- Billing information

### FCM Token Lifecycle
1. **Mobile App Registration**: App obtains FCM token from Firebase SDK
2. **Token Registration**: App sends token to server via API
3. **Token Storage**: Server stores token in customer profile
4. **Push Notifications**: Server uses stored tokens to send notifications
5. **Token Updates**: App re-registers token when it changes

---

## FCM Token Registration API

**Endpoint:** `POST /api/android/fcm-token/`  
**Purpose:** Mobile app registers or updates FCM token for push notifications

### Request Format
```json
{
    "customer_id": "550e8400-e29b-41d4-a716-446655440000",
    "fcm_token": "fcm_registration_token_from_firebase_sdk"
}
```

### Success Response (200 OK)
```json
{
    "success": true,
    "customer_id": "550e8400-e29b-41d4-a716-446655440000",
    "message": "FCM token registered successfully"
}
```

### Error Responses

**Invalid Request Data (400 Bad Request):**
```json
{
    "success": false,
    "message": "Invalid request data",
    "errors": {
        "customer_id": ["This field is required."],
        "fcm_token": ["This field may not be blank."]
    }
}
```

**Customer Not Found (404 Not Found):**
```json
{
    "success": false,
    "message": "Customer not found"
}
```

**Server Error (500 Internal Server Error):**
```json
{
    "success": false,
    "message": "Failed to register FCM token: [error details]"
}
```

### Request Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `customer_id` | UUID | Yes | Customer's unique identifier |
| `fcm_token` | String | Yes | FCM registration token from Firebase SDK (max 255 chars) |

### Response Fields

| Field | Type | Description |
|-------|------|-------------|
| `success` | Boolean | Operation success status |
| `customer_id` | String | Customer UUID (echoed back) |
| `message` | String | Success/error message |

---

## Postman Collection

### Environment Variables
Create a Postman environment with these variables:
```
base_url: http://localhost:8000
customer_id: 550e8400-e29b-41d4-a716-446655440000
fcm_token: your_fcm_token_here
```

### Sample Request
```
Method: POST
URL: {{base_url}}/api/android/fcm-token/
Headers:
  Content-Type: application/json

Body (raw JSON):
{
    "customer_id": "{{customer_id}}",
    "fcm_token": "{{fcm_token}}"
}
```

### Postman Collection JSON
```json
{
    "info": {
        "name": "FCM Token APIs - Water Rental System",
        "description": "FCM token management APIs collection",
        "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
    },
    "item": [
        {
            "name": "FCM Token Registration",
            "request": {
                "method": "POST",
                "header": [
                    {
                        "key": "Content-Type",
                        "value": "application/json"
                    }
                ],
                "body": {
                    "mode": "raw",
                    "raw": "{\n    \"customer_id\": \"{{customer_id}}\",\n    \"fcm_token\": \"{{fcm_token}}\"\n}"
                },
                "url": {
                    "raw": "{{base_url}}/api/android/fcm-token/",
                    "host": ["{{base_url}}"],
                    "path": ["api", "android", "fcm-token", ""]
                },
                "description": "Register or update FCM token for push notifications"
            },
            "response": []
        }
    ],
    "variable": [
        {
            "key": "base_url",
            "value": "http://localhost:8000",
            "type": "string"
        },
        {
            "key": "customer_id",
            "value": "550e8400-e29b-41d4-a716-446655440000",
            "type": "string"
        },
        {
            "key": "fcm_token",
            "value": "your_fcm_token_here",
            "type": "string"
        }
    ]
}
```

---

## Testing Scenarios

### 1. Valid Token Registration
- **Purpose:** Verify successful FCM token registration
- **Setup:** Use valid customer_id and FCM token
- **Expected:** 200 OK with success message

### 2. Invalid Customer ID
- **Purpose:** Verify customer validation
- **Setup:** Use non-existent customer UUID
- **Expected:** 404 Not Found with "Customer not found" message

### 3. Missing Required Fields
- **Purpose:** Verify input validation
- **Setup:** Send request without customer_id or fcm_token
- **Expected:** 400 Bad Request with validation errors

### 4. Token Update
- **Purpose:** Verify token updates work correctly
- **Setup:** Register token, then register a different token for same customer
- **Expected:** 200 OK (second registration should update the token)

### 5. Inactive Customer
- **Purpose:** Verify active customer requirement
- **Setup:** Use customer_id of inactive customer
- **Expected:** 404 Not Found with "Customer not found" message

---

## Integration Guide

### Android Integration

#### 1. Add Firebase Dependencies
```gradle
// build.gradle (app level)
dependencies {
    implementation 'com.google.firebase:firebase-messaging:23.1.0'
}
```

#### 2. Get FCM Token
```kotlin
// In your MainActivity or Application class
FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
    if (!task.isSuccessful) {
        Log.w(TAG, "Fetching FCM registration token failed", task.exception)
        return@addOnCompleteListener
    }

    // Get new FCM registration token
    val token = task.result
    Log.d(TAG, "FCM Token: $token")

    // Send token to your server
    registerFCMToken(token)
}
```

#### 3. Register Token with Server
```kotlin
private fun registerFCMToken(token: String) {
    val customerId = getCustomerIdFromPreferences() // Your customer ID

    val requestBody = JSONObject().apply {
        put("customer_id", customerId)
        put("fcm_token", token)
    }

    // Make HTTP POST request to /api/android/fcm-token/
    // Handle success/error responses
}
```

#### 4. Handle Token Updates
```kotlin
// Listen for token updates
FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
    if (task.isSuccessful) {
        val newToken = task.result
        // Re-register with server when token changes
        registerFCMToken(newToken)
    }
}
```

### iOS Integration

#### 1. Get FCM Token
```swift
// In AppDelegate
func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String?) {
    print("Firebase registration token: \(fcmToken)")

    let dataDict: [String: String] = ["token": fcmToken ?? ""]
    NotificationCenter.default.post(
        name: Notification.Name("FCMToken"),
        object: nil,
        userInfo: dataDict
    )

    // Send token to server
    registerFCMToken(fcmToken)
}
```

#### 2. Register Token with Server
```swift
func registerFCMToken(_ token: String?) {
    guard let token = token, let customerId = getCustomerId() else { return }

    let url = URL(string: "https://your-api-url/api/android/fcm-token/")!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")

    let body: [String: Any] = [
        "customer_id": customerId,
        "fcm_token": token
    ]

    request.httpBody = try? JSONSerialization.data(withJSONObject: body)

    URLSession.shared.dataTask(with: request) { data, response, error in
        // Handle response
    }.resume()
}
```

---

## Notification Types

The system can send various types of push notifications:

### 1. Water Usage Alerts
- High usage warnings
- Low balance alerts
- Usage limit exceeded

### 2. Payment Notifications
- Payment due reminders
- Payment successful confirmations
- Failed payment alerts

### 3. Device Status Updates
- Device offline alerts
- Maintenance required notifications
- Firmware update available

### 4. System Messages
- Account status changes
- Service announcements
- Emergency alerts

---

## Security Considerations

1. **Token Validation**: Always validate FCM tokens before storing
2. **Customer Verification**: Ensure customer exists and is active
3. **Token Updates**: Handle token refresh scenarios
4. **Privacy**: FCM tokens contain no personal information
5. **Rate Limiting**: Implement rate limiting for token registration

---

## Troubleshooting

### Common Issues

**"Customer not found" error:**
- Verify customer_id is a valid UUID
- Check if customer account is active
- Ensure customer exists in database

**FCM token not working:**
- Verify FCM token format (should be long alphanumeric string)
- Check Firebase project configuration
- Ensure FCM SDK is properly initialized

**Notifications not received:**
- Verify FCM token is registered with server
- Check device notification permissions
- Ensure app is not in Doze mode (Android)

---

## API Rate Limits

- **Token Registration**: 10 requests per minute per customer
- **Token Updates**: Unlimited (tokens should be updated when they change)
- **Error Retries**: Implement exponential backoff for failed requests

---

*Last updated: January 15, 2026*
*API Version: 1.0*</content>
<parameter name="filePath">e:\first_project\FCM_TOKEN_APIS_DOCUMENTATION.md