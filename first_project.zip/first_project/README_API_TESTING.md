# Water Rental System API Testing

This directory contains comprehensive API documentation and testing resources for the Water Rental System.

## Files

### 📖 API_DOCUMENTATION.md
Complete API documentation including:
- Overview and authentication
- All endpoint specifications with examples
- Request/response formats
- Error handling
- Data models
- Security notes

### 🧪 Water_Rental_API_Postman_Collection.json
Ready-to-import Postman collection with:
- Pre-configured requests for all endpoints
- Automated tests for validation
- Environment variables setup
- Sample data for testing

## Quick Start

### 1. Import Postman Collection
1. Open Postman
2. Click "Import" button
3. Select "File" tab
4. Choose `Water_Rental_API_Postman_Collection.json`
5. Import the collection

### 2. Set Up Environment
1. Create a new environment in Postman
2. Add these variables:
   - `base_url`: `http://localhost:8000` (or your server URL)
   - `customer_uuid`: (leave empty, will be set automatically)

### 3. Start Testing
1. Run "Customer Registration" request first
2. The `customer_uuid` will be automatically saved
3. Test other endpoints using the saved UUID

## Test Flow

```
Registration → Login → Get Info → Submit Complaint → Get Complaints
```

## Key Endpoints Tested

- **POST** `/api/android/register/` - Customer registration
- **POST** `/api/android/login/` - Customer login
- **GET** `/api/android/userinfo/{uuid}/` - Get customer info
- **GET** `/api/android/complaint/{uuid}/` - Get customer complaints
- **POST** `/api/android/complaint/{uuid}/` - Submit new complaint

## Notes

- All requests include automated tests
- Environment variables are updated automatically
- Tests validate response structure and success status
- Collection includes both positive and negative test scenarios

## Support

For questions about the API or testing:
1. Check `API_DOCUMENTATION.md` first
2. Review the Postman collection examples
3. Contact the development team

---

**Last Updated:** January 15, 2026</content>
<parameter name="filePath">e:\first_project\README_API_TESTING.md