# ESP Device & FCM APIs Documentation

This document provides comprehensive testing details for ESP device APIs and FCM token management in the Water Rental System.

## Table of Contents
- [Authentication](#authentication)
- [ESP Block/Unblock Status API](#esp-blockunblock-status-api)
- [ESP OTA Status Check API](#esp-ota-status-check-api)
- [ESP Sensor Data API](#esp-sensor-data-api)
- [ESP Device Health API](#esp-device-health-api)
- [ESP Calibration Factor API](#esp-calibration-factor-api)
- [FCM Token Registration API](#fcm-token-registration-api)
- [Postman Collection](#postman-collection)
- [Testing Scenarios](#testing-scenarios)

## Authentication

All ESP APIs use HMAC-SHA256 signature authentication with the following components:
- **device_id**: ESP32 chip ID (32 characters)
- **ts**: Unix timestamp (seconds since epoch)
- **signature**: HMAC-SHA256 hash of message + device token
- **token**: Device authentication token

### Signature Generation
```javascript
// JavaScript example for signature generation
const crypto = require('crypto');

function generateSignature(deviceId, timestamp, message, token) {
    const msg = deviceId + timestamp + message;
    return crypto.createHmac('sha256', token).update(msg, 'utf8').digest('hex');
}
```

---

## ESP Block/Unblock Status API

**Endpoint:** `GET /api/esp/block-unblock-status/`  
**Purpose:** ESP device requests its block/unblock status

### Request Format
```json
{
    "device_id": "ESP32_CHIP_ID_HERE",
    "ts": 1704067200,
    "signature": "hmac_sha256_signature_here",
    "token": "device_token_here"
}
```

### Success Response (200 OK)
```json
{
    "success": true,
    "device_id": "ESP32_CHIP_ID_HERE",
    "block_unblock": true,
    "timestamp": 1704067200
}
```

### Error Responses

**Invalid Signature (403 Forbidden):**
```json
{
    "success": false,
    "message": "Invalid signature"
}
```

**Device Not Found (404 Not Found):**
```json
{
    "success": false,
    "message": "Device not found or invalid token"
}
```

### Postman Test
```
Method: GET
URL: {{base_url}}/api/esp/block-unblock-status/
Headers:
  Content-Type: application/json

Body (raw JSON):
{
    "device_id": "ESP32_TEST_DEVICE_001",
    "ts": 1704067200,
    "signature": "calculated_signature_here",
    "token": "test_device_token_123"
}
```

---

## ESP OTA Status Check API

**Endpoint:** `GET /api/esp/ota-status-check/`  
**Purpose:** ESP device requests OTA update status information

### Request Format
```json
{
    "device_id": "ESP32_CHIP_ID_HERE",
    "ts": 1704067200,
    "signature": "hmac_sha256_signature_here",
    "token": "device_token_here"
}
```

### Success Response (200 OK)
```json
{
    "success": true,
    "device_id": "ESP32_CHIP_ID_HERE",
    "ota_available": true,
    "current_version": "1.0.0",
    "board_type": "esp32",
    "last_check": 1704067200,
    "message": "OTA status check successful"
}
```

### Blocked Device Response (403 Forbidden)
```json
{
    "success": false,
    "message": "Device is blocked",
    "ota_available": false
}
```

### Postman Test
```
Method: GET
URL: {{base_url}}/api/esp/ota-status-check/
Headers:
  Content-Type: application/json

Body (raw JSON):
{
    "device_id": "ESP32_TEST_DEVICE_001",
    "ts": 1704067200,
    "signature": "calculated_signature_here",
    "token": "test_device_token_123"
}
```

---

## ESP Sensor Data API

**Endpoint:** `POST /api/esp/sensor-data/`  
**Purpose:** ESP device submits sensor readings to the server

### Request Format
```json
{
    "device_id": "ESP32_CHIP_ID_HERE",
    "ts": 1704067200,
    "signature": "hmac_sha256_signature_here",
    "token": "device_token_here",
    "data": [
        {
            "esp_timestamp": 1704067200,
            "total_volume": "100.5",
            "current_volume": "50.2",
            "water_quality": "Good",
            "tds": "150",
            "ph": "7.2",
            "system_health": "OK"
        },
        {
            "esp_timestamp": 1704067205,
            "total_volume": "101.0",
            "current_volume": "50.7",
            "water_quality": "Good",
            "tds": "152",
            "ph": "7.1",
            "system_health": "OK"
        }
    ]
}
```

### Success Response (202 Accepted)
```json
{
    "success": true,
    "device_id": "ESP32_CHIP_ID_HERE",
    "data_points": 2,
    "timestamp": 1704067200,
    "message": "Sensor data accepted for processing"
}
```

### Postman Test
```
Method: POST
URL: {{base_url}}/api/esp/sensor-data/
Headers:
  Content-Type: application/json

Body (raw JSON):
{
    "device_id": "ESP32_TEST_DEVICE_001",
    "ts": 1704067200,
    "signature": "calculated_signature_here",
    "token": "test_device_token_123",
    "data": [
        {
            "esp_timestamp": 1704067200,
            "total_volume": "100.5",
            "current_volume": "50.2",
            "water_quality": "Good",
            "tds": "150",
            "ph": "7.2",
            "system_health": "OK"
        }
    ]
}
```

---

## ESP Device Health API

**Endpoint:** `POST /api/esp/device-health/`  
**Purpose:** ESP device reports its health status

### Request Format
```json
{
    "device_id": "ESP32_CHIP_ID_HERE",
    "ts": 1704067200,
    "signature": "hmac_sha256_signature_here",
    "token": "device_token_here",
    "health_status": "OK"
}
```

### Success Response (200 OK)
```json
{
    "success": true,
    "device_id": "ESP32_CHIP_ID_HERE",
    "health_status": "OK",
    "timestamp": 1704067200,
    "message": "Device health status updated successfully"
}
```

### Health Status Values
- `"OK"` - Device functioning normally
- `"WARNING"` - Minor issues detected
- `"ERROR"` - Critical issues requiring attention
- `"MAINTENANCE"` - Device needs maintenance

### Postman Test
```
Method: POST
URL: {{base_url}}/api/esp/device-health/
Headers:
  Content-Type: application/json

Body (raw JSON):
{
    "device_id": "ESP32_TEST_DEVICE_001",
    "ts": 1704067200,
    "signature": "calculated_signature_here",
    "token": "test_device_token_123",
    "health_status": "OK"
}
```

---

## ESP Calibration Factor API

**Endpoint:** `GET /api/esp/calibration-factor/`  
**Purpose:** ESP device requests its calibration factor

### Request Format
```json
{
    "device_id": "ESP32_CHIP_ID_HERE",
    "ts": 1704067200,
    "signature": "hmac_sha256_signature_here",
    "token": "device_token_here"
}
```

### Success Response (200 OK)
```json
{
    "success": true,
    "device_id": "ESP32_CHIP_ID_HERE",
    "calibration_factor": 1.234,
    "recorded_at": "2024-01-15T10:30:00Z",
    "timestamp": 1704067200,
    "message": "Calibration factor retrieved successfully"
}
```

### No Calibration Data Response (200 OK)
```json
{
    "success": true,
    "device_id": "ESP32_CHIP_ID_HERE",
    "calibration_factor": 1.0,
    "recorded_at": null,
    "timestamp": 1704067200,
    "message": "Calibration factor retrieved successfully"
}
```

### Postman Test
```
Method: GET
URL: {{base_url}}/api/esp/calibration-factor/
Headers:
  Content-Type: application/json

Body (raw JSON):
{
    "device_id": "ESP32_TEST_DEVICE_001",
    "ts": 1704067200,
    "signature": "calculated_signature_here",
    "token": "test_device_token_123"
}
```

---

## FCM Token Registration API

**Endpoint:** `POST /api/android/fcm-token/`  
**Purpose:** Mobile app registers FCM token for push notifications

### Request Format
```json
{
    "customer_id": "550e8400-e29b-41d4-a716-446655440000",
    "fcm_token": "fcm_registration_token_from_firebase_sdk"
}
```

### Success Response (200 OK)
```json
{
    "success": true,
    "customer_id": "550e8400-e29b-41d4-a716-446655440000",
    "message": "FCM token registered successfully"
}
```

### Postman Test
```
Method: POST
URL: {{base_url}}/api/android/fcm-token/
Headers:
  Content-Type: application/json

Body (raw JSON):
{
    "customer_id": "{{customer_id}}",
    "fcm_token": "{{fcm_token}}"
}
```

---

## Postman Collection

### Environment Variables
Create a Postman environment with these variables:
```
base_url: http://localhost:8000
device_id: ESP32_TEST_DEVICE_001
device_token: test_device_token_123
customer_id: 550e8400-e29b-41d4-a716-446655440000
fcm_token: your_fcm_token_here
```

### Pre-request Script
Add this pre-request script to automatically generate signatures:

```javascript
// Pre-request Script for ESP APIs
const moment = require('moment');
const crypto = require('crypto');

// Get current timestamp
const ts = Math.floor(Date.now() / 1000);
pm.environment.set("current_ts", ts);

// Generate signature based on request
const deviceId = pm.environment.get("device_id");
const token = pm.environment.get("device_token");

if (pm.request.body && pm.request.body.raw) {
    const requestBody = JSON.parse(pm.request.body.raw);

    let message = deviceId + ts;

    // Add additional message components based on API
    if (requestBody.health_status) {
        message += requestBody.health_status;
    } else if (requestBody.data) {
        // For sensor data, include the JSON data in signature
        message += JSON.stringify(requestBody.data, Object.keys(requestBody.data).sort());
    }

    const signature = crypto.createHmac('sha256', token).update(message, 'utf8').digest('hex');
    pm.environment.set("current_signature", signature);

    // Update request body with current ts and signature
    requestBody.ts = ts;
    requestBody.signature = signature;
    pm.request.body.raw = JSON.stringify(requestBody, null, 2);
}
```

### Sample Collection JSON
```json
{
    "info": {
        "name": "ESP Device APIs",
        "description": "Water Rental System ESP Device APIs Collection"
    },
    "variable": [
        {
            "key": "base_url",
            "value": "http://localhost:8000"
        }
    ],
    "item": [
        {
            "name": "ESP Block/Unblock Status",
            "request": {
                "method": "GET",
                "header": [
                    {
                        "key": "Content-Type",
                        "value": "application/json"
                    }
                ],
                "body": {
                    "mode": "raw",
                    "raw": "{\n    \"device_id\": \"{{device_id}}\",\n    \"ts\": {{current_ts}},\n    \"signature\": \"{{current_signature}}\",\n    \"token\": \"{{device_token}}\"\n}"
                },
                "url": {
                    "raw": "{{base_url}}/api/esp/block-unblock-status/",
                    "host": ["{{base_url}}"],
                    "path": ["api", "esp", "block-unblock-status", ""]
                }
            }
        }
    ]
}
```

---

## Testing Scenarios

### 1. Valid Authentication Test
- **Purpose:** Verify successful API authentication
- **Setup:** Use valid device_id, token, and correct signature
- **Expected:** 200 OK with success: true

### 2. Invalid Signature Test
- **Purpose:** Verify signature validation
- **Setup:** Use incorrect or tampered signature
- **Expected:** 403 Forbidden with "Invalid signature" message

### 3. Device Not Found Test
- **Purpose:** Verify device existence validation
- **Setup:** Use non-existent device_id
- **Expected:** 404 Not Found with "Device not found" message

### 4. Blocked Device Test
- **Purpose:** Verify blocked device handling
- **Setup:** Use device with block_unblock = false
- **Expected:** 403 Forbidden with "Device is blocked" message

### 5. Timestamp Replay Test
- **Purpose:** Verify replay attack prevention
- **Setup:** Use old timestamp (>60 seconds ago)
- **Expected:** 403 Forbidden with "Request expired" message

### 6. Invalid JSON Test
- **Purpose:** Verify JSON validation
- **Setup:** Send malformed JSON or missing required fields
- **Expected:** 400 Bad Request with validation errors

### 7. Batch Sensor Data Test
- **Purpose:** Verify batch data processing
- **Setup:** Send multiple sensor readings in single request
- **Expected:** 202 Accepted with correct data_points count

### 8. Concurrent Requests Test
- **Purpose:** Verify system handles multiple simultaneous requests
- **Setup:** Send multiple API calls simultaneously
- **Expected:** All requests processed successfully without conflicts

---

## Error Codes Summary

| Status Code | Error Type | Common Causes |
|-------------|------------|---------------|
| 400 | Bad Request | Invalid JSON, missing required fields |
| 403 | Forbidden | Invalid signature, device blocked, expired timestamp |
| 404 | Not Found | Device not found, invalid token |
| 500 | Internal Server Error | Server-side processing errors |

---

## Security Best Practices

1. **Always use HTTPS** in production
2. **Validate timestamps** within reasonable window (±60 seconds)
3. **Use strong device tokens** (32+ characters)
4. **Implement rate limiting** to prevent abuse
5. **Log all API requests** for monitoring
6. **Regular token rotation** for enhanced security

---

## Troubleshooting

### Common Issues

**"Invalid signature" error:**
- Verify signature generation algorithm
- Check token matches device token in database
- Ensure message format is correct: `device_id + ts + additional_data`

**"Device not found" error:**
- Verify device_id exists in Customer model
- Check device_token matches exactly
- Ensure device is_active = true

**"Request expired" error:**
- Check system clock synchronization
- Ensure timestamp is current (within 60 seconds)
- Verify timestamp format (Unix seconds, not milliseconds)

**Database connection issues:**
- Check Django database configuration
- Verify PostgreSQL service is running
- Check database credentials and permissions

---

*Last updated: January 15, 2026*
*API Version: 1.0*</content>
<parameter name="filePath">e:\first_project\ESP_DEVICE_APIS_DOCUMENTATION.md