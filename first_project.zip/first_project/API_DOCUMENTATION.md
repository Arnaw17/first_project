# Water Rental System API Documentation

## Overview

This API documentation covers the Water Rental System's REST API endpoints, specifically designed for the Android mobile application. The API provides comprehensive functionality for customer management, water usage tracking, payments, and complaint management.

**Base URL:** `http://your-domain.com/api/android/`
**Version:** 1.0
**Date:** January 15, 2026

## Authentication

The API uses UUID-based authentication for customer endpoints. Each customer has a unique UUID that must be included in the URL path for authentication.

### Authentication Flow
1. Customer registers via `/api/android/register/` (returns customer UUID)
2. Customer logs in via `/api/android/login/` (validates credentials)
3. Use the customer UUID in subsequent API calls

## API Endpoints

### 1. Customer Registration

**Endpoint:** `POST /api/android/register/`

**Description:** Register a new customer account

**Request Body:**
```json
{
    "name": "John Doe",
    "email": "john.doe@example.com",
    "phone_no": "9876543210",
    "address": "123 Main Street",
    "city": "Mumbai",
    "pincode": "400001",
    "subscription_plan": 1
}
```

**Response (Success - 201):**
```json
{
    "success": true,
    "message": "Customer registered successfully",
    "data": {
        "customer_id": "550e8400-e29b-41d4-a716-446655440000",
        "name": "John Doe",
        "email": "john.doe@example.com",
        "phone_no": "9876543210"
    }
}
```

**Response (Error - 400):**
```json
{
    "success": false,
    "message": "Email already exists",
    "errors": {
        "email": ["This email is already registered"]
    }
}
```

### 2. Customer Login

**Endpoint:** `POST /api/android/login/`

**Description:** Authenticate customer credentials

**Request Body:**
```json
{
    "email": "john.doe@example.com",
    "password": "customer_password"
}
```

**Response (Success - 200):**
```json
{
    "success": true,
    "message": "Login successful",
    "data": {
        "customer_id": "550e8400-e29b-41d4-a716-446655440000",
        "name": "John Doe",
        "email": "john.doe@example.com",
        "phone_no": "9876543210",
        "is_blocked": false
    }
}
```

### 3. Get Customer Info

**Endpoint:** `GET /api/android/userinfo/{customer_uuid}/`

**Description:** Retrieve customer profile information

**Response (Success - 200):**
```json
{
    "success": true,
    "message": "Customer info retrieved successfully",
    "data": {
        "id": "550e8400-e29b-41d4-a716-446655440000",
        "name": "John Doe",
        "email": "john.doe@example.com",
        "phone_no": "9876543210",
        "address": "123 Main Street",
        "city": "Mumbai",
        "pincode": "400001",
        "subscription_plan": "Basic Plan",
        "block_unblock": true,
        "created_at": "2024-01-15T10:30:00Z"
    }
}
```

### 4. Get Customer Location

**Endpoint:** `GET /api/android/userlocation/{customer_uuid}/`

**Description:** Retrieve customer location information

### 5. Get Water Usage

**Endpoint:** `GET /api/android/waterusage/{customer_uuid}/`

**Description:** Retrieve customer's water usage data

### 6. Get Recharge Info

**Endpoint:** `GET /api/android/rechargeinfo/{customer_uuid}/`

**Description:** Retrieve customer's recharge/payment history

### 7. Get Payment Details

**Endpoint:** `GET /api/android/paymentdetails/{customer_uuid}/`

**Description:** Retrieve detailed payment information

### 8. Get Subscription Plans

**Endpoint:** `GET /api/android/subscriptioninfo/`

**Description:** Retrieve available subscription plans

### 9. Customer Complaints

**Endpoint:** `GET /api/android/complaint/{customer_uuid}/`

**Description:** Retrieve all complaints submitted by the customer

**Response (Success - 200):**
```json
{
    "success": true,
    "message": "Complaints retrieved successfully",
    "data": [
        {
            "customer": "John Doe",
            "phone_no": "9876543210",
            "email": "john.doe@example.com",
            "ticket_number": "TKT-20260115-001",
            "problem_statement": "Water quality is poor",
            "complain_date": "2024-01-15T14:30:00Z",
            "priority": "high",
            "assigned_person": "technician1",
            "assigned_person_details": "Assigned to senior technician",
            "assigned_at": "2024-01-15T15:00:00Z",
            "resolution_notes": "Filter replaced",
            "closed_date": "2024-01-16T10:00:00Z",
            "status": "resolved"
        }
    ]
}
```

**Endpoint:** `POST /api/android/complaint/{customer_uuid}/`

**Description:** Submit a new complaint

**Request Body:**
```json
{
    "phone_no": "9876543210",
    "problem_statement": "Water pressure is low",
    "priority": "medium"
}
```

**Response (Success - 201):**
```json
{
    "success": true,
    "message": "Complaint submitted successfully",
    "data": {
        "complaint_id": 1,
        "customer": "John Doe",
        "phone_no": "9876543210",
        "email": "john.doe@example.com",
        "ticket_number": "TKT-20260115-002",
        "problem_statement": "Water pressure is low",
        "complain_date": "2024-01-15T16:00:00Z",
        "priority": "medium",
        "status": "open"
    }
}
```

## Error Responses

All API endpoints return standardized error responses:

```json
{
    "success": false,
    "message": "Error description",
    "errors": {
        "field_name": ["Error details"]
    }
}
```

### Common HTTP Status Codes
- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden (Account blocked)
- `404` - Not Found
- `500` - Internal Server Error

## Postman Testing Guide

### 1. Environment Setup

Create a new environment in Postman with the following variables:
- `base_url`: `http://localhost:8000` (or your server URL)
- `customer_uuid`: (will be set after registration/login)

### 2. Test Collections

#### Collection: Water Rental API Tests

#### Folder: Authentication

**Request 1: Customer Registration**
- Method: POST
- URL: `{{base_url}}/api/android/register/`
- Headers:
  - Content-Type: application/json
- Body (raw JSON):
```json
{
    "name": "Test Customer",
    "email": "test@example.com",
    "phone_no": "9876543210",
    "address": "Test Address",
    "city": "Test City",
    "pincode": "400001",
    "subscription_plan": 1
}
```
- Tests:
```javascript
pm.test("Registration successful", function () {
    var jsonData = pm.response.json();
    pm.expect(jsonData.success).to.eql(true);
    pm.environment.set("customer_uuid", jsonData.data.customer_id);
});
```

**Request 2: Customer Login**
- Method: POST
- URL: `{{base_url}}/api/android/login/`
- Headers:
  - Content-Type: application/json
- Body (raw JSON):
```json
{
    "email": "test@example.com",
    "password": "test_password"
}
```
- Tests:
```javascript
pm.test("Login successful", function () {
    var jsonData = pm.response.json();
    pm.expect(jsonData.success).to.eql(true);
    pm.environment.set("customer_uuid", jsonData.data.customer_id);
});
```

#### Folder: Customer Operations

**Request 1: Get Customer Info**
- Method: GET
- URL: `{{base_url}}/api/android/userinfo/{{customer_uuid}}/`
- Tests:
```javascript
pm.test("Customer info retrieved", function () {
    var jsonData = pm.response.json();
    pm.expect(jsonData.success).to.eql(true);
    pm.expect(jsonData.data).to.have.property('name');
});
```

**Request 2: Get Customer Complaints**
- Method: GET
- URL: `{{base_url}}/api/android/complaint/{{customer_uuid}}/`
- Tests:
```javascript
pm.test("Complaints retrieved", function () {
    var jsonData = pm.response.json();
    pm.expect(jsonData.success).to.eql(true);
    pm.expect(jsonData.data).to.be.an('array');
});
```

**Request 3: Submit New Complaint**
- Method: POST
- URL: `{{base_url}}/api/android/complaint/{{customer_uuid}}/`
- Headers:
  - Content-Type: application/json
- Body (raw JSON):
```json
{
    "phone_no": "9876543210",
    "problem_statement": "Test complaint - water quality issue",
    "priority": "medium"
}
```
- Tests:
```javascript
pm.test("Complaint submitted", function () {
    var jsonData = pm.response.json();
    pm.expect(jsonData.success).to.eql(true);
    pm.expect(jsonData.data).to.have.property('ticket_number');
});
```

### 3. Running Tests

1. Import the collection into Postman
2. Set up the environment variables
3. Run requests in order:
   - Registration/Login (to get customer_uuid)
   - Other authenticated requests

### 4. Test Scenarios

#### Positive Test Cases:
- Successful registration
- Successful login
- Retrieve customer info
- Retrieve complaints (empty list initially)
- Submit complaint
- Retrieve complaints (should show submitted complaint)

#### Negative Test Cases:
- Invalid UUID format
- Non-existent customer
- Blocked customer account
- Invalid request data
- Missing required fields

## Data Models

### Customer
```json
{
    "id": "uuid",
    "name": "string",
    "email": "string",
    "phone_no": "string",
    "address": "string",
    "city": "string",
    "pincode": "string",
    "subscription_plan": "string",
    "block_unblock": "boolean",
    "created_at": "datetime"
}
```

### Complaint
```json
{
    "customer": "string",
    "phone_no": "string",
    "email": "string",
    "ticket_number": "string",
    "problem_statement": "string",
    "complain_date": "datetime",
    "priority": "low|medium|high|critical",
    "assigned_person": "string|null",
    "assigned_person_details": "string|null",
    "assigned_at": "datetime|null",
    "resolution_notes": "string|null",
    "closed_date": "datetime|null",
    "status": "open|in_progress|resolved|closed|pending"
}
```

## Security Notes

1. All customer-specific endpoints require valid UUID in URL
2. Customers can only access their own data
3. Blocked customers receive 403 Forbidden responses
4. All requests should be made over HTTPS in production
5. Implement rate limiting to prevent abuse

## Support

For API support or questions:
- Check this documentation first
- Test with Postman using the provided collection
- Contact the development team for technical issues

---

**Last Updated:** January 15, 2026
**API Version:** 1.0</content>
<parameter name="filePath">e:\first_project\API_DOCUMENTATION.md